# Agent Bridge

Extensao Chromium MV3 que funciona como uma camada entre a mensagem humana e o agente de IA. O usuario escreve normalmente; no envio, a extensao detecta a intencao, escolhe um perfil especialista, valida a estrutura e acrescenta apenas o contexto consolidado que ainda e util.

## Fluxo automatico

1. Detecta o campo de mensagem dentro do agente.
2. Classifica o pedido em geral, codigo, pesquisa, planejamento, escrita, dados ou seguranca.
3. Recomenda uma capacidade: rapida/economica, equilibrada, agente de codigo, pesquisa com web, multimodal ou raciocinio avancado.
4. Injeta um envelope compacto no momento do envio.
5. Mostra no proprio chat o estado, o agente ativo, a rota e a validacao.
6. Avalia a resposta com uma rubrica do perfil e compara medias com e sem filtro, sem duplicar chamadas.

O botao verde no indicador liga ou desliga o filtro. Quando desligado, as mensagens passam sem alteracao.

## Comandos no prompt

- `limpar`: pede ao agente para consolidar somente objetivos, decisoes, fatos, restricoes, preferencias, acertos e proximos passos. A memoria e salva localmente e um novo contexto e aberto depois da confirmacao.
- `/status`: abre o painel de status sem enviar mensagem ao agente.
- `/ativar` e `/desativar`: controlam o filtro.
- `/perfil auto`: restaura o roteamento automatico.
- `/perfil coding`: fixa temporariamente um perfil pelo identificador.
- `/ajuda`: mostra os comandos.

O comando `limpar` nao exclui a conversa do historico do provedor. Ele inicia um chat sem o contexto antigo, que e o que reduz os tokens enviados nas interacoes seguintes. A porcentagem exibida e calculada com os tamanhos reais do historico lido e da memoria salva; uma reducao de 90% e possivel em conversas longas, mas nao e garantida.

## Medicao de melhoria

Depois de cada resposta, o indicador avalia relevancia, profundidade e criterios especificos do perfil. Em codigo, por exemplo, verifica se ha solucao executavel, testes, validacao e tradeoffs, alem de penalizar memoizacao apresentada como ganho automatico. A extensao mantem medias separadas para respostas filtradas e respostas enviadas enquanto o filtro esta desligado. Isso cria uma comparacao real ao longo do uso, sem pagar por uma segunda resposta artificial.

Essa pontuacao e uma rubrica local, nao uma garantia de corretude factual. Para pesquisa, seguranca ou decisoes de alto impacto, as fontes e evidencias continuam sendo obrigatorias.

## Agentes suportados

- ChatGPT
- Claude
- Gemini
- Microsoft Copilot
- Perplexity

Os seletores ficam isolados por provedor e possuem alternativas genericas para pequenas mudancas de interface.

## Limite importante sobre modelos

Um prompt nao consegue trocar sozinho o modelo selecionado pela plataforma. O Agent Bridge recomenda a capacidade ideal e aplica um perfil especialista ao modelo atual. A troca real de modelo so pode ser automatizada quando o provedor oferece uma API ou um seletor estavel para isso; a interface deixa essa diferenca explicita para nao produzir uma falsa economia.

## Instalar localmente

1. Abra `chrome://extensions`.
2. Ative o modo do desenvolvedor.
3. Clique em `Carregar sem compactacao`.
4. Selecione a pasta `agent-prompt-extension`.
5. Ao atualizar o codigo, clique em `Recarregar` no cartao da extensao e recarregue a pagina do agente.

## Testar

```powershell
npm.cmd test
```

Os testes cobrem roteamento, economia, idempotencia, comandos, consolidacao, limite de memoria e integridade do manifest.
