importScripts("core.js");

const CORE = globalThis.AgentPromptCore;
const SCHEMA_VERSION = 3;

const DEFAULT_SETTINGS = {
  schemaVersion: SCHEMA_VERSION,
  enabled: true,
  showIndicator: true,
  autoNewChatAfterClean: true,
  manualProfileId: "auto",
  profiles: CORE.DEFAULT_PROFILES,
  activeMemory: "",
  memorySnapshots: [],
  sessionInteractions: [],
  pendingConsolidation: null,
  lastRoute: null,
  lastEvaluation: null,
  lastResponseEvaluation: null,
  lastConsolidation: null,
  responseBenchmarks: {
    optimized: { count: 0, total: 0, average: 0 },
    baseline: { count: 0, total: 0, average: 0 },
    profiles: {}
  },
  stats: {
    optimizedPrompts: 0,
    baselinePrompts: 0,
    commandsHandled: 0,
    consolidatedChats: 0,
    transcriptChars: 0,
    memoryChars: 0
  }
};

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function mergeProfiles(storedProfiles, schemaVersion) {
  const incoming = Array.isArray(storedProfiles) ? storedProfiles : [];
  const custom = incoming.filter((profile) => !CORE.DEFAULT_PROFILES.some((item) => item.id === profile.id));
  const defaults = CORE.DEFAULT_PROFILES.map((defaultProfile) => {
    const stored = incoming.find((profile) => profile.id === defaultProfile.id);
    if (!stored) return clone(defaultProfile);
    return {
      ...defaultProfile,
      ...stored,
      instruction: Number(schemaVersion) >= SCHEMA_VERSION && stored.instruction
        ? stored.instruction
        : defaultProfile.instruction,
      keywords: Array.isArray(stored.keywords) && stored.keywords.length
        ? stored.keywords
        : defaultProfile.keywords,
      capability: stored.capability || defaultProfile.capability
    };
  });
  return [...defaults, ...custom];
}

function migrateSettings(raw) {
  const previous = raw || {};
  const legacyMemory = Number(previous.schemaVersion) >= SCHEMA_VERSION
    ? previous.activeMemory || ""
    : [
        previous.activeMemory,
        previous.customPromptNotes,
        ...(Array.isArray(previous.promptHistory) ? previous.promptHistory : [])
      ].filter(Boolean).join("\n");
  const stats = { ...DEFAULT_SETTINGS.stats, ...(previous.stats || {}) };
  const responseBenchmarks = {
    ...clone(DEFAULT_SETTINGS.responseBenchmarks),
    ...(previous.responseBenchmarks || {}),
    optimized: {
      ...DEFAULT_SETTINGS.responseBenchmarks.optimized,
      ...(previous.responseBenchmarks?.optimized || {})
    },
    baseline: {
      ...DEFAULT_SETTINGS.responseBenchmarks.baseline,
      ...(previous.responseBenchmarks?.baseline || {})
    },
    profiles: previous.responseBenchmarks?.profiles || {}
  };

  return {
    ...clone(DEFAULT_SETTINGS),
    ...previous,
    schemaVersion: SCHEMA_VERSION,
    enabled: previous.enabled ?? previous.autoValidationEnabled ?? true,
    showIndicator: previous.showIndicator !== false,
    autoNewChatAfterClean: previous.autoNewChatAfterClean !== false,
    manualProfileId: previous.manualProfileId || "auto",
    profiles: mergeProfiles(previous.profiles, previous.schemaVersion),
    activeMemory: CORE.sanitizeMemory(legacyMemory),
    memorySnapshots: Array.isArray(previous.memorySnapshots) ? previous.memorySnapshots.slice(-10) : [],
    sessionInteractions: Array.isArray(previous.sessionInteractions) ? previous.sessionInteractions.slice(-30) : [],
    responseBenchmarks,
    stats
  };
}

function addBenchmarkSample(benchmarks, profileId, optimized, score) {
  const group = optimized ? "optimized" : "baseline";
  const current = benchmarks || DEFAULT_SETTINGS.responseBenchmarks;
  const bucket = current[group] || { count: 0, total: 0, average: 0 };
  const nextBucket = {
    count: bucket.count + 1,
    total: bucket.total + score,
    average: Math.round((bucket.total + score) / (bucket.count + 1))
  };
  const profiles = { ...(current.profiles || {}) };
  const profile = profiles[profileId] || {
    optimized: { count: 0, total: 0, average: 0 },
    baseline: { count: 0, total: 0, average: 0 }
  };
  const profileBucket = profile[group];
  profiles[profileId] = {
    ...profile,
    [group]: {
      count: profileBucket.count + 1,
      total: profileBucket.total + score,
      average: Math.round((profileBucket.total + score) / (profileBucket.count + 1))
    }
  };
  return { ...current, [group]: nextBucket, profiles };
}

async function getSettings() {
  const raw = await chrome.storage.local.get(null);
  const migrated = migrateSettings(raw);
  if (raw.schemaVersion !== SCHEMA_VERSION) {
    await chrome.storage.local.set(migrated);
  }
  return migrated;
}

async function updateSettings(patch) {
  const current = await getSettings();
  const next = migrateSettings({ ...current, ...patch });
  await chrome.storage.local.set(next);
  return next;
}

async function updateBadge(enabled, tabId) {
  const details = tabId ? { tabId } : {};
  await chrome.action.setBadgeText({ ...details, text: enabled ? "ON" : "OFF" });
  await chrome.action.setBadgeBackgroundColor({
    ...details,
    color: enabled ? "#0f9f7a" : "#9f3144"
  });
  await chrome.action.setTitle({
    ...details,
    title: enabled ? "Agent Bridge ativo" : "Agent Bridge desativado"
  });
}

async function initialize() {
  const settings = await getSettings();
  await chrome.storage.local.set(settings);
  await updateBadge(settings.enabled);
}

chrome.runtime.onInstalled.addListener(initialize);
chrome.runtime.onStartup.addListener(initialize);

chrome.storage.onChanged.addListener(async (changes, areaName) => {
  if (areaName === "local" && changes.enabled) {
    await updateBadge(Boolean(changes.enabled.newValue));
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    const settings = await getSettings();
    const tabId = sender.tab?.id;

    if (message?.type === "APS_GET_STATE") {
      if (tabId) await updateBadge(settings.enabled, tabId);
      sendResponse({ ok: true, state: settings });
      return;
    }

    if (message?.type === "APS_SET_ENABLED") {
      const next = await updateSettings({ enabled: Boolean(message.enabled) });
      await updateBadge(next.enabled, tabId);
      sendResponse({ ok: true, state: next });
      return;
    }

    if (message?.type === "APS_SET_MANUAL_PROFILE") {
      const requested = String(message.profileId || "auto");
      const exists = requested === "auto" || settings.profiles.some((profile) => profile.id === requested);
      const next = await updateSettings({ manualProfileId: exists ? requested : "auto" });
      sendResponse({ ok: true, state: next });
      return;
    }

    if (message?.type === "APS_RECORD_PROMPT") {
      const original = String(message.original || "").slice(0, 6000);
      const optimized = message.optimized !== false;
      const interaction = {
        at: Date.now(),
        original,
        optimized,
        route: message.route || null,
        page: String(message.page || "").slice(0, 180)
      };
      const interactions = [...settings.sessionInteractions, interaction].slice(-30);
      const stats = {
        ...settings.stats,
        optimizedPrompts: settings.stats.optimizedPrompts + (optimized ? 1 : 0),
        baselinePrompts: settings.stats.baselinePrompts + (optimized ? 0 : 1)
      };
      const next = await updateSettings({
        sessionInteractions: interactions,
        lastRoute: message.route || null,
        lastEvaluation: message.evaluation || null,
        stats
      });
      sendResponse({ ok: true, state: next });
      return;
    }

    if (message?.type === "APS_RECORD_RESPONSE") {
      const score = Math.max(0, Math.min(100, Number(message.evaluation?.score) || 0));
      const optimized = message.optimized !== false;
      const profileId = String(message.evaluation?.profileId || message.route?.profileId || "general");
      const evaluation = {
        ...(message.evaluation || {}),
        score,
        optimized,
        at: Date.now()
      };
      const next = await updateSettings({
        lastResponseEvaluation: evaluation,
        responseBenchmarks: addBenchmarkSample(settings.responseBenchmarks, profileId, optimized, score)
      });
      sendResponse({ ok: true, state: next });
      return;
    }

    if (message?.type === "APS_RECORD_COMMAND") {
      const next = await updateSettings({
        stats: {
          ...settings.stats,
          commandsHandled: settings.stats.commandsHandled + 1
        }
      });
      sendResponse({ ok: true, state: next });
      return;
    }

    if (message?.type === "APS_MARK_CONSOLIDATION") {
      const pendingConsolidation = {
        marker: String(message.marker || ""),
        transcriptLength: Number(message.transcriptLength) || 0,
        providerId: String(message.providerId || "generic"),
        startedAt: Date.now()
      };
      const next = await updateSettings({ pendingConsolidation });
      sendResponse({ ok: true, state: next });
      return;
    }

    if (message?.type === "APS_COMPLETE_CONSOLIDATION") {
      const memory = CORE.sanitizeMemory(message.memory || "");
      if (!memory) {
        sendResponse({ ok: false, error: "A memoria consolidada ficou vazia." });
        return;
      }
      const transcriptLength = Number(message.transcriptLength) || settings.pendingConsolidation?.transcriptLength || 0;
      const reduction = CORE.estimateReduction(transcriptLength, memory.length);
      const snapshot = {
        at: Date.now(),
        memory,
        transcriptLength,
        reduction
      };
      const next = await updateSettings({
        activeMemory: memory,
        memorySnapshots: [...settings.memorySnapshots, snapshot].slice(-10),
        sessionInteractions: [],
        pendingConsolidation: null,
        lastConsolidation: snapshot,
        stats: {
          ...settings.stats,
          consolidatedChats: settings.stats.consolidatedChats + 1,
          transcriptChars: settings.stats.transcriptChars + transcriptLength,
          memoryChars: settings.stats.memoryChars + memory.length
        }
      });
      sendResponse({ ok: true, state: next, reduction });
      return;
    }

    if (message?.type === "APS_UPDATE_SETTINGS") {
      const allowed = {};
      if (Array.isArray(message.patch?.profiles)) allowed.profiles = message.patch.profiles;
      if (typeof message.patch?.showIndicator === "boolean") allowed.showIndicator = message.patch.showIndicator;
      if (typeof message.patch?.autoNewChatAfterClean === "boolean") {
        allowed.autoNewChatAfterClean = message.patch.autoNewChatAfterClean;
      }
      if (typeof message.patch?.activeMemory === "string") {
        allowed.activeMemory = CORE.sanitizeMemory(message.patch.activeMemory);
      }
      const next = await updateSettings(allowed);
      sendResponse({ ok: true, state: next });
      return;
    }

    if (message?.type === "APS_CLEAR_MEMORY") {
      const next = await updateSettings({
        activeMemory: "",
        memorySnapshots: [],
        pendingConsolidation: null,
        sessionInteractions: [],
        lastConsolidation: null
      });
      sendResponse({ ok: true, state: next });
      return;
    }

    sendResponse({ ok: false, error: "Comando desconhecido." });
  })().catch((error) => {
    sendResponse({ ok: false, error: error?.message || "Falha interna da extensao." });
  });
  return true;
});
