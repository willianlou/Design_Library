(function startAgentBridge() {
  "use strict";

  if (globalThis.__AGENT_BRIDGE_CONTENT_LOADED__) return;
  globalThis.__AGENT_BRIDGE_CONTENT_LOADED__ = true;

  const CORE = globalThis.AgentPromptCore;
  if (!CORE) return;

  const PROVIDERS = [
    {
      id: "chatgpt",
      name: "ChatGPT",
      hosts: ["chatgpt.com", "chat.openai.com"],
      composers: ["#prompt-textarea", "textarea[data-id='root']", "main [contenteditable='true']"],
      sendButtons: ["button[data-testid='send-button']", "button[aria-label*='Send']", "button[aria-label*='Enviar']"],
      assistants: ["[data-message-author-role='assistant']"],
      newChatUrl: () => `${location.origin}/`
    },
    {
      id: "claude",
      name: "Claude",
      hosts: ["claude.ai"],
      composers: ["[contenteditable='true'][data-testid*='input']", ".ProseMirror[contenteditable='true']", "fieldset textarea"],
      sendButtons: ["button[aria-label*='Send']", "button[aria-label*='Enviar']", "fieldset button[type='button']"],
      assistants: [".font-claude-response", "[data-testid*='assistant']", "[data-is-streaming='true']"],
      newChatUrl: () => `${location.origin}/new`
    },
    {
      id: "gemini",
      name: "Gemini",
      hosts: ["gemini.google.com"],
      composers: ["rich-textarea .ql-editor[contenteditable='true']", ".ql-editor[contenteditable='true']", "textarea"],
      sendButtons: ["button[aria-label*='Enviar']", "button[aria-label*='Send']", ".send-button"],
      assistants: ["model-response", ".model-response-text", ".response-container"],
      newChatUrl: () => `${location.origin}/app`
    },
    {
      id: "perplexity",
      name: "Perplexity",
      hosts: ["www.perplexity.ai", "perplexity.ai"],
      composers: ["textarea", "[contenteditable='true']"],
      sendButtons: ["button[aria-label*='Submit']", "button[aria-label*='Send']", "button[type='submit']"],
      assistants: ["[data-testid='answer']", "[data-testid*='assistant']", ".prose"],
      newChatUrl: () => `${location.origin}/`
    },
    {
      id: "copilot",
      name: "Copilot",
      hosts: ["copilot.microsoft.com"],
      composers: ["textarea", "[contenteditable='true']"],
      sendButtons: ["button[aria-label*='Submit']", "button[aria-label*='Send']", "button[aria-label*='Enviar']"],
      assistants: ["[data-content='ai-message']", "[data-testid*='assistant']"],
      newChatUrl: () => `${location.origin}/`
    }
  ];

  const GENERIC_PROVIDER = {
    id: "generic",
    name: "Agente de IA",
    hosts: [],
    composers: ["textarea", "[contenteditable='true']"],
    sendButtons: ["button[type='submit']", "button[aria-label*='Send']", "button[aria-label*='Enviar']"],
    assistants: ["[data-message-author-role='assistant']", "[data-testid*='assistant']", ".model-response-text"],
    newChatUrl: () => location.href
  };

  const provider = PROVIDERS.find((item) => item.hosts.includes(location.hostname)) || GENERIC_PROVIDER;
  let state = null;
  let ui = null;
  let previewRoute = null;
  let localPending = null;
  let completionLocked = false;
  let pendingResponse = null;
  let lastPrepared = null;
  let routeTimer = 0;
  let scanTimer = 0;
  let responseTimer = 0;

  function visible(element) {
    if (!element || !(element instanceof Element)) return false;
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return rect.width > 40 && rect.height > 20 && style.display !== "none" && style.visibility !== "hidden";
  }

  function findComposer() {
    const candidates = provider.composers.flatMap((selector) => [...document.querySelectorAll(selector)]);
    const unique = [...new Set(candidates)].filter(visible);
    return unique.sort((left, right) => {
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      const leftScore = leftRect.bottom + leftRect.width;
      const rightScore = rightRect.bottom + rightRect.width;
      return rightScore - leftScore;
    })[0] || null;
  }

  function composerText(element) {
    if (!element) return "";
    if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) {
      return element.value || "";
    }
    return element.innerText || element.textContent || "";
  }

  function setComposerText(element, value) {
    if (!element) return false;
    const text = String(value || "");
    element.focus();

    if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) {
      const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      if (setter) setter.call(element, text);
      else element.value = text;
    } else {
      element.textContent = text;
    }

    try {
      element.dispatchEvent(new InputEvent("input", {
        bubbles: true,
        composed: true,
        inputType: text ? "insertText" : "deleteContentBackward",
        data: text
      }));
    } catch (_error) {
      element.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    }
    element.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  function clearComposer(element) {
    setComposerText(element, "");
  }

  function closestButton(target) {
    return target instanceof Element ? target.closest("button") : null;
  }

  function isSendAction(target, composer) {
    const button = closestButton(target);
    if (!button || button.disabled || !visible(button)) return false;
    if (provider.sendButtons.some((selector) => button.matches(selector))) return true;

    const label = CORE.normalizeText([
      button.getAttribute("aria-label"),
      button.getAttribute("title"),
      button.textContent
    ].filter(Boolean).join(" "));
    if (/parar|stop|cancelar/.test(label)) return false;
    if (/enviar|send|submit|mandar/.test(label)) return true;
    return button.type === "submit" && Boolean(composer.closest("form")?.contains(button));
  }

  function post(message) {
    return chrome.runtime.sendMessage(message).catch(() => ({ ok: false }));
  }

  function formatCount(value) {
    const number = Number(value) || 0;
    if (number < 1000) return String(number);
    return `${(number / 1000).toFixed(number >= 10000 ? 0 : 1)}k`;
  }

  function createUi() {
    const root = document.createElement("aside");
    root.id = "agent-bridge-status";
    root.setAttribute("aria-live", "polite");
    root.innerHTML = `
      <div class="aps-dock">
        <button class="aps-identity" type="button" aria-expanded="false" aria-label="Abrir status do Agent Bridge">
          <span class="aps-orbit" aria-hidden="true"><i></i></span>
          <span class="aps-identity-copy">
            <strong data-aps="state">Iniciando</strong>
            <small data-aps="profile">Detectando agente</small>
          </span>
        </button>
        <button class="aps-power" type="button" aria-label="Desativar Agent Bridge" title="Ativar ou desativar">
          <span aria-hidden="true"></span>
        </button>
      </div>
      <section class="aps-panel" hidden>
        <header>
          <div>
            <span class="aps-kicker">Agent Bridge</span>
            <h2>Filtro do agente</h2>
          </div>
          <button class="aps-close" type="button" aria-label="Fechar">×</button>
        </header>
        <div class="aps-route-grid">
          <div><span>Agente ativo</span><strong data-aps="agent">Automatico</strong></div>
          <div><span>Rota ideal</span><strong data-aps="route">Economica</strong></div>
          <div><span>Validacao</span><strong data-aps="validation">Aguardando prompt</strong></div>
          <div><span>Memoria util</span><strong data-aps="memory">Vazia</strong></div>
        </div>
        <p class="aps-explanation" data-aps="explanation"></p>
        <div class="aps-commands">
          <span>Comandos no campo do chat</span>
          <code>limpar</code><code>/status</code><code>/ativar</code><code>/desativar</code><code>/perfil auto</code>
        </div>
        <p class="aps-provider" data-aps="provider"></p>
      </section>
      <div class="aps-toast" role="status" hidden></div>
    `;
    document.documentElement.appendChild(root);

    const identity = root.querySelector(".aps-identity");
    const panel = root.querySelector(".aps-panel");
    identity.addEventListener("click", () => {
      const opening = panel.hidden;
      panel.hidden = !opening;
      identity.setAttribute("aria-expanded", String(opening));
    });
    root.querySelector(".aps-close").addEventListener("click", () => {
      panel.hidden = true;
      identity.setAttribute("aria-expanded", "false");
    });
    root.querySelector(".aps-power").addEventListener("click", async () => {
      if (!state) return;
      const response = await post({ type: "APS_SET_ENABLED", enabled: !state.enabled });
      if (response?.state) state = response.state;
      renderUi();
      showToast(state.enabled ? "Filtro automatico ativado" : "Filtro automatico desativado");
    });
    return root;
  }

  function showToast(message, duration) {
    if (!ui) return;
    const toast = ui.querySelector(".aps-toast");
    toast.textContent = String(message || "");
    toast.hidden = false;
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => {
      toast.hidden = true;
    }, duration || 3200);
  }

  function renderUi() {
    if (!state) return;
    if (!ui) ui = createUi();
    ui.hidden = state.showIndicator === false;
    ui.dataset.enabled = state.enabled ? "true" : "false";
    ui.dataset.pending = state.pendingConsolidation || localPending ? "true" : "false";

    const route = previewRoute || state.lastRoute || CORE.routePrompt("", state);
    const pending = state.pendingConsolidation || localPending;
    const status = pending ? "Consolidando" : state.enabled ? "Automatico ativo" : "Desativado";
    const validation = pending
      ? "Extraindo acertos"
      : state.lastResponseEvaluation
        ? `Resposta ${state.lastResponseEvaluation.score}/100`
        : state.lastEvaluation
          ? `Estrutura ${state.lastEvaluation.scoreAfter}/100`
        : "Automatico";

    ui.querySelector("[data-aps='state']").textContent = status;
    ui.querySelector("[data-aps='profile']").textContent = state.enabled
      ? `${route.profileName} · ${route.capability}`
      : "Clique no botao para ativar";
    ui.querySelector("[data-aps='agent']").textContent = route.profileName;
    ui.querySelector("[data-aps='route']").textContent = route.capability;
    ui.querySelector("[data-aps='validation']").textContent = validation;
    ui.querySelector("[data-aps='memory']").textContent = state.activeMemory
      ? `${formatCount(state.activeMemory.length)} caracteres`
      : "Vazia";
    const responseIssue = state.lastResponseEvaluation?.issues?.[0];
    ui.querySelector("[data-aps='explanation']").textContent = pending
      ? "O agente esta separando somente decisoes, acertos e restricoes. Ao concluir, a extensao inicia um contexto novo."
      : responseIssue
        ? `Ultima resposta: ${responseIssue}.`
        : route.reason;
    ui.querySelector("[data-aps='provider']").textContent = `${provider.name} · dados salvos apenas neste navegador`;
    const power = ui.querySelector(".aps-power");
    power.setAttribute("aria-label", state.enabled ? "Desativar Agent Bridge" : "Ativar Agent Bridge");
    power.title = state.enabled ? "Desativar filtro" : "Ativar filtro";
  }

  function openPanel() {
    if (!ui) return;
    ui.querySelector(".aps-panel").hidden = false;
    ui.querySelector(".aps-identity").setAttribute("aria-expanded", "true");
  }

  function collectTranscript() {
    const entries = [];
    const seen = new Set();
    const add = (role, element) => {
      const text = String(element?.innerText || element?.textContent || "").replace(/\s+/g, " ").trim();
      if (!text || text.length < 2) return;
      const key = `${role}:${text}`;
      if (seen.has(key)) return;
      seen.add(key);
      entries.push({ role, text });
    };

    document.querySelectorAll("[data-message-author-role]").forEach((element) => {
      add(element.getAttribute("data-message-author-role") === "assistant" ? "Assistente" : "Usuario", element);
    });
    document.querySelectorAll("user-query, [data-testid*='user-message'], .font-user-message, [data-content='user-message']")
      .forEach((element) => add("Usuario", element));
    document.querySelectorAll("model-response, .model-response-text, .font-claude-response, [data-testid*='assistant'], [data-content='ai-message']")
      .forEach((element) => add("Assistente", element));

    let transcript = entries.slice(-50).map((item) => `${item.role}: ${item.text}`).join("\n\n");
    if (!transcript && state?.sessionInteractions?.length) {
      transcript = state.sessionInteractions
        .slice(-30)
        .map((item) => `Usuario: ${item.original}`)
        .join("\n\n");
    }
    return transcript.slice(-CORE.MAX_TRANSCRIPT_CHARS);
  }

  function assistantTexts() {
    const result = [];
    const seen = new Set();
    for (const selector of provider.assistants) {
      for (const element of document.querySelectorAll(selector)) {
        const text = String(element.innerText || element.textContent || "").trim();
        if (!text || seen.has(text)) continue;
        seen.add(text);
        result.push(text);
      }
    }
    return result.slice(-16);
  }

  function generationIsActive() {
    if (document.querySelector("[data-is-streaming='true']")) return true;
    return [...document.querySelectorAll("button")].some((button) => {
      if (!visible(button)) return false;
      const label = CORE.normalizeText([
        button.getAttribute("aria-label"),
        button.getAttribute("title"),
        button.textContent
      ].filter(Boolean).join(" "));
      return /parar|interromper|stop generating|cancelar resposta/.test(label);
    });
  }

  function beginClean(composer) {
    const transcript = collectTranscript();
    const marker = CORE.createMemoryMarker(`${Date.now()}${Math.random()}`);
    const prompt = CORE.buildConsolidationPrompt({
      transcript,
      currentMemory: state.activeMemory,
      marker
    });
    localPending = {
      marker,
      transcriptLength: transcript.length,
      providerId: provider.id,
      startedAt: Date.now()
    };
    pendingResponse = null;
    setComposerText(composer, prompt);
    state.pendingConsolidation = localPending;
    renderUi();
    showToast("Consolidacao iniciada. Aguarde o novo contexto.", 4500);
    void post({
      type: "APS_MARK_CONSOLIDATION",
      marker,
      transcriptLength: transcript.length,
      providerId: provider.id
    }).then((response) => {
      if (response?.state) {
        state = response.state;
        renderUi();
      }
    });
    void post({ type: "APS_RECORD_COMMAND" });
  }

  async function handleLocalCommand(command, composer) {
    clearComposer(composer);
    void post({ type: "APS_RECORD_COMMAND" });

    if (command.type === "enable" || command.type === "disable") {
      const enabled = command.type === "enable";
      const response = await post({ type: "APS_SET_ENABLED", enabled });
      if (response?.state) state = response.state;
      renderUi();
      showToast(enabled ? "Filtro automatico ativado" : "Filtro automatico desativado");
      return;
    }

    if (command.type === "profile") {
      if (!command.profileId) {
        const names = ["auto", ...state.profiles.map((profile) => profile.id)].join(", ");
        showToast(`Use /perfil seguido de: ${names}`, 5200);
        openPanel();
        return;
      }
      const response = await post({ type: "APS_SET_MANUAL_PROFILE", profileId: command.profileId });
      if (response?.state) state = response.state;
      previewRoute = null;
      renderUi();
      showToast(state.manualProfileId === "auto" ? "Deteccao automatica restaurada" : `Perfil fixado: ${state.manualProfileId}`);
      return;
    }

    openPanel();
    if (command.type === "help") {
      showToast("Comandos: limpar, /status, /ativar, /desativar e /perfil auto", 5200);
    } else {
      showToast(state.enabled ? "Agent Bridge esta ativo e automatico" : "Agent Bridge esta desativado");
    }
  }

  function stopLocalSubmission(event) {
    event.preventDefault();
    event.stopPropagation();
    if (typeof event.stopImmediatePropagation === "function") event.stopImmediatePropagation();
  }

  function prepareSubmission(event) {
    if (!state) return;
    const composer = findComposer();
    if (!composer) return;
    const original = composerText(composer).trim();
    if (!original || original.includes(CORE.BRIDGE_MARKER) || original.includes("[AGENT_BRIDGE:CONSOLIDAR]")) return;

    const now = Date.now();
    if (lastPrepared?.text === original && now - lastPrepared.at < 900) return;

    const command = CORE.parseCommand(original);
    if (command && command.type !== "clean") {
      stopLocalSubmission(event);
      void handleLocalCommand(command, composer);
      return;
    }

    if (command?.type === "clean") {
      lastPrepared = { text: original, at: now };
      beginClean(composer);
      return;
    }

    const beforeAssistant = assistantTexts().at(-1) || "";
    if (!state.enabled) {
      const route = CORE.routePrompt(original, state);
      lastPrepared = { text: original, at: now };
      pendingResponse = { original, route, optimized: false, beforeAssistant };
      previewRoute = route;
      state.lastRoute = route;
      renderUi();
      void post({
        type: "APS_RECORD_PROMPT",
        original,
        route,
        evaluation: null,
        optimized: false,
        page: location.origin
      }).then((response) => {
        if (response?.state) state = response.state;
      });
      return;
    }
    const result = CORE.optimizePrompt(original, state);
    if (!result.changed) return;
    lastPrepared = { text: original, at: now };
    pendingResponse = { original, route: result.route, optimized: true, beforeAssistant };
    setComposerText(composer, result.optimized);
    previewRoute = result.route;
    state.lastRoute = result.route;
    state.lastEvaluation = result.evaluation;
    renderUi();
    showToast(`${result.route.profileName}: prompt validado em ${result.evaluation.scoreAfter}/100`);
    void post({
      type: "APS_RECORD_PROMPT",
      original: result.original,
      route: result.route,
      evaluation: result.evaluation,
      optimized: true,
      page: location.origin
    }).then((response) => {
      if (response?.state) state = response.state;
    });
  }

  function scheduleRoutePreview(target) {
    clearTimeout(routeTimer);
    routeTimer = setTimeout(() => {
      const composer = findComposer();
      if (!composer || (target !== composer && !composer.contains(target))) return;
      const text = composerText(composer).trim();
      if (!text || text.includes(CORE.BRIDGE_MARKER) || CORE.parseCommand(text)) {
        previewRoute = null;
      } else {
        previewRoute = CORE.routePrompt(text, state);
      }
      renderUi();
    }, 180);
  }

  async function completeConsolidation(memory, pending) {
    if (completionLocked) return;
    completionLocked = true;
    const response = await post({
      type: "APS_COMPLETE_CONSOLIDATION",
      memory,
      transcriptLength: pending.transcriptLength
    });
    if (!response?.ok) {
      completionLocked = false;
      showToast(response?.error || "Nao foi possivel salvar a consolidacao.", 5000);
      return;
    }

    state = response.state;
    localPending = null;
    renderUi();
    showToast(`Memoria salva. Reducao estimada: ${response.reduction}%`, 5000);

    if (state.autoNewChatAfterClean && provider.id !== "generic") {
      setTimeout(() => location.assign(provider.newChatUrl()), 1400);
    } else {
      completionLocked = false;
    }
  }

  function scanForConsolidation() {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(() => {
      const pending = localPending || state?.pendingConsolidation;
      if (!pending?.marker || completionLocked) return;
      const responses = assistantTexts().reverse();
      for (const response of responses) {
        const memory = CORE.parseConsolidatedMemory(response, pending.marker);
        if (memory) {
          void completeConsolidation(memory, pending);
          break;
        }
      }
    }, 350);
  }

  function scheduleResponseEvaluation() {
    clearTimeout(responseTimer);
    responseTimer = setTimeout(() => {
      if (!pendingResponse || localPending || state?.pendingConsolidation) return;
      if (generationIsActive()) return;
      const responses = assistantTexts();
      const latest = responses.at(-1) || "";
      if (!latest || latest === pendingResponse.beforeAssistant || latest.length < 60) return;

      const tracked = pendingResponse;
      pendingResponse = null;
      const evaluation = CORE.evaluateResponse(tracked.original, latest, tracked.route);
      evaluation.optimized = tracked.optimized;
      void post({
        type: "APS_RECORD_RESPONSE",
        evaluation,
        route: tracked.route,
        optimized: tracked.optimized
      }).then((response) => {
        if (!response?.state) return;
        state = response.state;
        renderUi();
        showToast(`Resposta ${evaluation.summary}: ${evaluation.score}/100`);
      });
    }, 1400);
  }

  function bindPageEvents() {
    document.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" || event.shiftKey || event.isComposing) return;
      const composer = findComposer();
      if (!composer || (event.target !== composer && !composer.contains(event.target))) return;
      prepareSubmission(event);
    }, true);

    document.addEventListener("click", (event) => {
      const composer = findComposer();
      if (!composer || !isSendAction(event.target, composer)) return;
      prepareSubmission(event);
    }, true);

    document.addEventListener("submit", (event) => {
      const composer = findComposer();
      if (!composer || !event.target.contains(composer)) return;
      prepareSubmission(event);
    }, true);

    document.addEventListener("input", (event) => {
      const composer = findComposer();
      if (!composer || (event.target !== composer && !composer.contains(event.target))) return;
      scheduleRoutePreview(event.target);
    }, true);

    const observer = new MutationObserver(() => {
      scanForConsolidation();
      scheduleResponseEvaluation();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });

    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local" || !state) return;
      for (const [key, change] of Object.entries(changes)) {
        state[key] = change.newValue;
      }
      renderUi();
    });
  }

  async function initialize() {
    const response = await post({ type: "APS_GET_STATE" });
    if (!response?.state) return;
    state = response.state;
    localPending = state.pendingConsolidation;
    renderUi();
    bindPageEvents();
    scanForConsolidation();
  }

  void initialize();
})();
