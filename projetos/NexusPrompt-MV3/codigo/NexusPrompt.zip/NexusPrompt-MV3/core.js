(function initAgentPromptCore(root, factory) {
  const api = factory();
  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
  root.AgentPromptCore = api;
})(typeof globalThis !== "undefined" ? globalThis : self, function createAgentPromptCore() {
  "use strict";

  const BRIDGE_MARKER = "[AGENT_BRIDGE:v2]";
  const MAX_MEMORY_CHARS = 2400;
  const MAX_TRANSCRIPT_CHARS = 28000;

  const DEFAULT_PROFILES = [
    {
      id: "general",
      name: "Geral objetivo",
      description: "Pedidos cotidianos, explicacoes e tarefas diretas.",
      capability: "Rapido e economico",
      keywords: [],
      instruction:
        "Responda diretamente ao objetivo. Nao invente contexto e so pergunte quando faltar uma informacao essencial."
    },
    {
      id: "coding",
      name: "Engenharia de software",
      description: "Implementacao, depuracao, arquitetura e revisao de codigo.",
      capability: "Agente de codigo",
      keywords: [
        "codigo", "programar", "funcao", "react", "typescript", "javascript", "python", "api", "bug",
        "erro", "teste", "componente", "refatorar", "banco de dados", "sql", "git", "deploy", "frontend", "backend"
      ],
      instruction:
        "Defina o comportamento a validar antes de codificar. Entregue uma solucao proporcional, verifique erros e testes e nao trate memoizacao ou abstracoes como otimizacao sem evidencia."
    },
    {
      id: "research",
      name: "Pesquisa verificada",
      description: "Busca, comparacao, fatos atuais e analise de fontes.",
      capability: "Pesquisa com web",
      keywords: [
        "pesquise", "pesquisa", "fontes", "referencias", "atual", "noticias", "compare", "mercado", "evidencias",
        "artigo", "estudo", "documentacao", "verifique", "cotacao", "preco"
      ],
      instruction:
        "Separe fatos de inferencias, use fontes atuais quando necessario e deixe incertezas explicitas. Compare opcoes pelos mesmos criterios."
    },
    {
      id: "planner",
      name: "Estrategia e planejamento",
      description: "Roadmaps, decisoes, processos e tarefas com dependencias.",
      capability: "Raciocinio avancado",
      keywords: [
        "plano", "planejamento", "roadmap", "estrategia", "priorizar", "decisao", "processo", "etapas", "cronograma",
        "arquitetura", "tradeoff", "riscos", "projeto"
      ],
      instruction:
        "Estruture o caminho recomendado, dependencias, riscos e criterios de sucesso. Mostre alternativas apenas quando mudarem a decisao."
    },
    {
      id: "writing",
      name: "Escrita e comunicacao",
      description: "Textos, revisoes, mensagens, roteiros e adaptacao de tom.",
      capability: "Rapido e economico",
      keywords: [
        "escreva", "reescreva", "texto", "email", "mensagem", "roteiro", "copy", "curriculo", "resumo", "traduzir",
        "traducao", "tom", "gramatica", "revisar texto"
      ],
      instruction:
        "Preserve a intencao, adapte o tom ao publico e elimine repeticoes. Entregue primeiro a versao pronta para uso."
    },
    {
      id: "data",
      name: "Dados e analise",
      description: "Planilhas, metricas, estatistica, SQL e visualizacao.",
      capability: "Codigo e analise",
      keywords: [
        "dados", "planilha", "excel", "csv", "metrica", "estatistica", "dashboard", "grafico", "tabela", "analise",
        "pandas", "power bi", "sql", "kpi"
      ],
      instruction:
        "Valide premissas e qualidade dos dados, explique o calculo e entregue uma saida reproduzivel. Nao confunda correlacao com causalidade."
    },
    {
      id: "security",
      name: "Seguranca e risco",
      description: "Ameacas, vulnerabilidades, privacidade e conformidade.",
      capability: "Raciocinio avancado",
      keywords: [
        "seguranca", "vulnerabilidade", "ameaca", "risco", "privacidade", "lgpd", "compliance", "auditoria", "ataque",
        "criptografia", "autenticacao", "autorizacao", "cve"
      ],
      instruction:
        "Calibre o risco com evidencias, diferencie hipotese de exploracao demonstrada e priorize mitigacoes verificaveis sem ocultar tradeoffs."
    }
  ];

  function normalizeText(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/\s+/g, " ")
      .trim();
  }

  function profileById(profiles, id) {
    return (profiles || []).find((profile) => profile.id === id) || (profiles || [])[0] || DEFAULT_PROFILES[0];
  }

  function keywordScore(text, keywords) {
    return (keywords || []).reduce((score, keyword) => {
      const normalizedKeyword = normalizeText(keyword);
      if (!normalizedKeyword || !text.includes(normalizedKeyword)) return score;
      return score + (normalizedKeyword.includes(" ") ? 3 : 2);
    }, 0);
  }

  function detectComplexity(original) {
    const text = String(original || "");
    const normalized = normalizeText(text);
    let score = 0;

    if (text.length > 180) score += 1;
    if (text.length > 600) score += 1;
    if ((text.match(/\n/g) || []).length >= 4) score += 1;
    if (/```|\b(class|interface|function|SELECT|CREATE TABLE|def)\b/.test(text)) score += 2;
    if (/arquitet|tradeoff|investigue|diagnost|compare|analise|otimiz|migre|refator|vulnerab|estrateg/i.test(normalized)) score += 2;
    if (/requisitos?|restricoes?|criterios?|casos? de teste|passo a passo/i.test(normalized)) score += 1;

    return {
      score,
      level: score >= 5 ? "alta" : score >= 2 ? "media" : "baixa"
    };
  }

  function selectCapability(profile, complexity, normalizedText) {
    if (/imagem|foto|audio|video|pdf|anexo|screenshot|captura de tela/.test(normalizedText)) {
      return { capability: "Multimodal", mode: "multimodal" };
    }

    if (profile.id === "research") return { capability: profile.capability || "Pesquisa com web", mode: "research" };
    if (profile.id === "coding") {
      return {
        capability: complexity.level === "alta" ? "Agente de codigo avancado" : profile.capability || "Agente de codigo",
        mode: "coding"
      };
    }
    if (profile.id === "data") return { capability: profile.capability || "Codigo e analise", mode: "analysis" };
    if (profile.id === "security" || (profile.id === "planner" && complexity.level !== "baixa")) {
      return { capability: profile.capability || "Raciocinio avancado", mode: "reasoning" };
    }
    if (complexity.level === "baixa") {
      return { capability: profile.capability || "Rapido e economico", mode: "economy" };
    }
    return { capability: "Modelo equilibrado", mode: "balanced" };
  }

  function routePrompt(original, settings) {
    const options = settings || {};
    const profiles = Array.isArray(options.profiles) && options.profiles.length ? options.profiles : DEFAULT_PROFILES;
    const normalized = normalizeText(original);
    const manualId = options.manualProfileId && options.manualProfileId !== "auto" ? options.manualProfileId : "";
    let selected = manualId ? profileById(profiles, manualId) : profileById(profiles, "general");
    let bestScore = manualId ? 100 : 0;

    if (!manualId) {
      for (const profile of profiles) {
        if (profile.id === "general") continue;
        const score = keywordScore(normalized, profile.keywords);
        if (score > bestScore) {
          selected = profile;
          bestScore = score;
        }
      }
    }

    const complexity = detectComplexity(original);
    const capability = selectCapability(selected, complexity, normalized);
    return {
      profileId: selected.id,
      profileName: selected.name,
      capability: capability.capability,
      mode: capability.mode,
      complexity: complexity.level,
      confidence: manualId ? 100 : bestScore > 0 ? Math.min(98, 58 + bestScore * 7) : 72,
      reason: manualId
        ? "Perfil fixado pelo usuario"
        : bestScore > 0
          ? "Perfil detectado pelo conteudo do pedido"
          : "Pedido geral sem especialidade dominante"
    };
  }

  function sanitizeMemory(value, maxChars) {
    const limit = Number(maxChars) > 0 ? Number(maxChars) : MAX_MEMORY_CHARS;
    const seen = new Set();
    const lines = String(value || "")
      .replace(/\[(?:\/?APS_MEMORY[^\]]*|\/?AGENT_BRIDGE[^\]]*)\]/gi, "")
      .split(/\r?\n/)
      .map((line) => line.replace(/^\s*[-*\d.)]+\s*/, "").trim())
      .filter(Boolean)
      .filter((line) => {
        const key = normalizeText(line);
        if (!key || seen.has(key)) return false;
        seen.add(key);
        return true;
      });

    const result = [];
    let size = 0;
    for (const line of lines) {
      const available = limit - size - (result.length ? 1 : 0);
      if (available <= 0) break;
      result.push(line.slice(0, available));
      size += Math.min(line.length, available) + (result.length > 1 ? 1 : 0);
    }
    return result.join("\n").trim();
  }

  function evaluatePrompt(original, optimized, route, memory) {
    const normalized = normalizeText(original);
    const signals = {
      objetivo: original.trim().length >= 12,
      contexto: original.length >= 80 || /porque|contexto|cenario|atual|tenho|preciso/.test(normalized),
      restricoes: /sem |com |deve|precisa|limite|requisito|nao |evite|apenas/.test(normalized),
      formato: /lista|tabela|codigo|json|passos|resumo|exemplo|arquivo/.test(normalized),
      validacao: /teste|valide|verifique|criterio|evidencia|resultado/.test(normalized)
    };
    const originalSignals = Object.values(signals).filter(Boolean).length;
    const scoreBefore = Math.min(82, 28 + originalSignals * 10 + Math.min(4, Math.floor(original.length / 180)) * 3);
    const scoreAfter = Math.min(98, Math.max(scoreBefore + 12, 78 + (route.profileId !== "general" ? 7 : 0) + (memory ? 4 : 0)));
    return {
      scoreBefore,
      scoreAfter,
      gain: scoreAfter - scoreBefore,
      addedChars: Math.max(0, optimized.length - original.length),
      estimatedAddedTokens: Math.ceil(Math.max(0, optimized.length - original.length) / 4),
      signals
    };
  }

  function optimizePrompt(original, settings) {
    const cleanOriginal = String(original || "").trim();
    const options = settings || {};
    const route = routePrompt(cleanOriginal, options);
    if (!cleanOriginal || cleanOriginal.includes(BRIDGE_MARKER)) {
      return {
        original: cleanOriginal,
        optimized: cleanOriginal,
        route,
        evaluation: evaluatePrompt(cleanOriginal, cleanOriginal, route, ""),
        changed: false
      };
    }

    const profiles = Array.isArray(options.profiles) && options.profiles.length ? options.profiles : DEFAULT_PROFILES;
    const profile = profileById(profiles, route.profileId);
    const memory = sanitizeMemory(options.activeMemory || "");
    const executionRule = route.mode === "economy"
      ? "Seja curto e resolva sem etapas desnecessarias."
      : route.complexity === "alta"
        ? "Finalize com uma saida utilizavel e valide as premissas decisivas."
        : "";
    const optimized = [
      BRIDGE_MARKER,
      profile.instruction,
      executionRule,
      memory ? `Memoria util:\n${memory}` : "",
      `Pedido:\n${cleanOriginal}`,
      "[/AGENT_BRIDGE]"
    ].filter(Boolean).join("\n");

    return {
      original: cleanOriginal,
      optimized,
      route,
      evaluation: evaluatePrompt(cleanOriginal, optimized, route, memory),
      changed: optimized !== cleanOriginal
    };
  }

  function parseCommand(value) {
    const raw = String(value || "").trim();
    const normalized = normalizeText(raw);
    if (/^\/?(?:limpar|limpar conversa|consolidar)$/.test(normalized)) return { type: "clean" };
    if (/^\/?(?:status|estado)$/.test(normalized)) return { type: "status" };
    if (/^\/?(?:ativar|ligar)$/.test(normalized)) return { type: "enable" };
    if (/^\/?(?:desativar|desligar)$/.test(normalized)) return { type: "disable" };

    const profileMatch = normalized.match(/^\/?perfil(?:\s+([a-z0-9_-]+))?$/);
    if (profileMatch) return { type: "profile", profileId: profileMatch[1] || "" };
    if (/^\/?ajuda$/.test(normalized)) return { type: "help" };
    return null;
  }

  function importantTerms(value) {
    const stopWords = new Set([
      "para", "como", "com", "uma", "uns", "das", "dos", "que", "por", "mais", "sobre", "preciso", "quero",
      "faca", "crie", "mostre", "isso", "esta", "este", "ser", "tem", "meu", "minha", "seu", "sua"
    ]);
    return [...new Set(normalizeText(value).split(/[^a-z0-9]+/).filter((word) => word.length >= 4 && !stopWords.has(word)))];
  }

  function evaluateResponse(original, response, route) {
    const answer = String(response || "").trim();
    const normalizedAnswer = normalizeText(answer);
    const normalizedOriginal = normalizeText(original);
    const selectedRoute = route || routePrompt(original, {});
    const terms = importantTerms(original).slice(0, 10);
    const matchedTerms = terms.filter((term) => normalizedAnswer.includes(term));
    const topicality = terms.length ? matchedTerms.length / terms.length : 0.7;
    const issues = [];
    const signals = {
      relevante: topicality >= 0.35,
      substancial: answer.length >= 120,
      acionavel: /```|\b(passos?|exemplo|codigo|use |execute|adicione|remova|configure|primeiro|1\.)\b/i.test(answer)
    };
    let score = 35 + Math.round(topicality * 25);
    if (signals.substancial) score += 10;
    if (signals.acionavel) score += 8;

    if (selectedRoute.profileId === "coding") {
      signals.codigo = /```|\b(function|const|let|class|interface|def|return|import|export)\b/.test(answer);
      signals.validacao = /test|valida|erro|edge case|caso limite|compatib|runtime|tipo/.test(normalizedAnswer);
      signals.tradeoff = /tradeoff|quando fizer sentido|quando necessario|medir|profil|nao e necessario|depende/.test(normalizedAnswer);
      if (signals.codigo) score += 12;
      else issues.push("faltou uma solucao executavel");
      if (signals.validacao) score += 8;
      else issues.push("faltou validar erros ou testes");
      if (signals.tradeoff) score += 6;
      if (/usecallback|react\.memo|usememo/.test(normalizedAnswer)
        && /otimiz|performance|re-render/.test(normalizedAnswer)
        && !/nao e necessario|apenas quando|so use|medir|profile|antes de usar/.test(normalizedAnswer)) {
        score -= 16;
        issues.push("memoizacao foi apresentada como otimizacao sem evidencia");
      }
      if (/validar uma funcao/.test(normalizedOriginal)
        && !/pode significar|interpretacao|voce quer|qual comportamento|depende do que/.test(normalizedAnswer)) {
        score -= 8;
        issues.push("a ambiguidade principal nao foi resolvida");
      }
    } else if (selectedRoute.profileId === "research") {
      signals.fontes = /https?:\/\/|fontes?|referencias?|segundo |documentacao/.test(normalizedAnswer);
      signals.incerteza = /incerteza|nao foi possivel|pode variar|ate |consultado|verifique/.test(normalizedAnswer);
      if (signals.fontes) score += 15;
      else issues.push("faltaram fontes verificaveis");
      if (signals.incerteza) score += 5;
    } else if (selectedRoute.profileId === "planner") {
      signals.etapas = /(^|\n)\s*(?:[-*]|\d+[.)])\s+/.test(answer);
      signals.riscos = /risco|dependenc|criterio|tradeoff|bloqueio/.test(normalizedAnswer);
      if (signals.etapas) score += 10;
      if (signals.riscos) score += 10;
      else issues.push("faltaram riscos ou dependencias");
    } else if (selectedRoute.profileId === "data") {
      signals.calculo = /formula|calculo|consulta|select |pandas|metrica|validar dados|amostra/.test(normalizedAnswer);
      if (signals.calculo) score += 15;
      else issues.push("faltou um calculo ou procedimento reproduzivel");
    } else if (selectedRoute.profileId === "writing") {
      signals.prontoParaUso = answer.length > 20 && !/^para (?:criar|escrever|reescrever)/i.test(normalizedAnswer);
      if (signals.prontoParaUso) score += 12;
      if (answer.length > Math.max(1800, String(original).length * 12)) {
        score -= 8;
        issues.push("a resposta ficou maior do que a tarefa exigia");
      }
    } else if (selectedRoute.profileId === "security") {
      signals.evidencia = /evidencia|explor|impacto|severidade|mitig|pre-condic|ameaca/.test(normalizedAnswer);
      if (signals.evidencia) score += 15;
      else issues.push("faltou calibrar risco e evidencia");
    }

    if (!signals.relevante) issues.push("baixa correspondencia com o pedido");
    if (!signals.substancial) issues.push("resposta curta demais para avaliar");
    score = Math.max(0, Math.min(100, score));
    return {
      score,
      summary: score >= 85 ? "forte" : score >= 70 ? "boa" : score >= 55 ? "parcial" : "fraca",
      profileId: selectedRoute.profileId,
      optimized: false,
      signals,
      issues: [...new Set(issues)].slice(0, 4),
      responseChars: answer.length
    };
  }

  function createMemoryMarker(seed) {
    const safeSeed = String(seed || Date.now()).replace(/[^a-zA-Z0-9]/g, "").slice(-12);
    return `APS_MEMORY_${safeSeed || "CURRENT"}`;
  }

  function buildConsolidationPrompt(input) {
    const options = input || {};
    const marker = options.marker || createMemoryMarker();
    const transcript = String(options.transcript || "").slice(-MAX_TRANSCRIPT_CHARS);
    const currentMemory = sanitizeMemory(options.currentMemory || "");
    return [
      "[AGENT_BRIDGE:CONSOLIDAR]",
      "Consolide esta conversa para continuar em um novo chat com o minimo de tokens e sem perder informacao util.",
      "Preserve somente: objetivo atual, decisoes confirmadas, fatos fornecidos pelo usuario, restricoes, preferencias, solucoes que funcionaram, erros ja descartados e proximos passos.",
      "Remova: saudacoes, repeticoes, tentativas que falharam, explicacoes genericas, logs extensos e qualquer detalhe sem efeito nas proximas respostas.",
      "Nao invente informacoes. Escreva pontos curtos, autoexplicativos e reutilizaveis, com no maximo 2.400 caracteres.",
      `Responda obrigatoriamente entre estes marcadores:\n[${marker}]\n- memoria consolidada\n[/${marker}]`,
      currentMemory ? `Memoria anterior a revisar e substituir:\n${currentMemory}` : "",
      `Conversa a consolidar:\n${transcript || "Nao foi possivel ler o historico visual. Consolide apenas o contexto disponivel nesta mensagem."}`,
      "[/AGENT_BRIDGE:CONSOLIDAR]"
    ].filter(Boolean).join("\n\n");
  }

  function parseConsolidatedMemory(value, marker) {
    if (!marker) return "";
    const escaped = String(marker).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const match = String(value || "").match(new RegExp(`\\[${escaped}\\]([\\s\\S]*?)\\[\\/${escaped}\\]`, "i"));
    return match ? sanitizeMemory(match[1]) : "";
  }

  function estimateReduction(beforeChars, afterChars) {
    const before = Math.max(0, Number(beforeChars) || 0);
    const after = Math.max(0, Number(afterChars) || 0);
    if (!before) return 0;
    return Math.max(0, Math.min(99, Math.round((1 - after / before) * 100)));
  }

  return {
    BRIDGE_MARKER,
    DEFAULT_PROFILES,
    MAX_MEMORY_CHARS,
    MAX_TRANSCRIPT_CHARS,
    normalizeText,
    profileById,
    detectComplexity,
    routePrompt,
    sanitizeMemory,
    evaluatePrompt,
    optimizePrompt,
    evaluateResponse,
    parseCommand,
    createMemoryMarker,
    buildConsolidationPrompt,
    parseConsolidatedMemory,
    estimateReduction
  };
});
