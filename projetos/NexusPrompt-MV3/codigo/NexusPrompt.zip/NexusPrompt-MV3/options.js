let currentProfiles = [];

async function send(message) {
  return chrome.runtime.sendMessage(message);
}

function setStatus(message, tone) {
  const element = document.getElementById("saveStatus");
  element.textContent = message;
  element.dataset.tone = tone || "neutral";
}

function field(labelText, fieldName, value, multiline, rows) {
  const label = document.createElement("label");
  const title = document.createElement("span");
  title.textContent = labelText;
  const input = multiline ? document.createElement("textarea") : document.createElement("input");
  input.dataset.field = fieldName;
  input.value = value || "";
  if (multiline) input.rows = rows || 3;
  label.append(title, input);
  return label;
}

function renderProfiles(profiles) {
  const root = document.getElementById("profiles");
  root.replaceChildren();

  profiles.forEach((profile, index) => {
    const row = document.createElement("article");
    row.className = "profile-row";

    const heading = document.createElement("header");
    const identity = document.createElement("div");
    const number = document.createElement("span");
    const name = document.createElement("strong");
    number.textContent = String(index + 1).padStart(2, "0");
    name.textContent = profile.name || "Novo perfil";
    identity.append(number, name);

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "remove-profile";
    remove.dataset.remove = String(index);
    remove.textContent = "Remover";
    heading.append(identity, remove);

    const identityGrid = document.createElement("div");
    identityGrid.className = "field-grid";
    identityGrid.append(
      field("Identificador", "id", profile.id),
      field("Nome exibido", "name", profile.name),
      field("Capacidade recomendada", "capability", profile.capability)
    );

    row.append(
      heading,
      identityGrid,
      field("Descricao", "description", profile.description, true, 2),
      field("Palavras para deteccao, separadas por virgula", "keywords", (profile.keywords || []).join(", "), true, 2),
      field("Instrucao especializada", "instruction", profile.instruction, true, 4)
    );
    root.appendChild(row);
  });
}

function collectProfiles() {
  return [...document.querySelectorAll(".profile-row")].map((row) => ({
    id: row.querySelector('[data-field="id"]').value.trim(),
    name: row.querySelector('[data-field="name"]').value.trim(),
    capability: row.querySelector('[data-field="capability"]').value.trim(),
    description: row.querySelector('[data-field="description"]').value.trim(),
    keywords: row.querySelector('[data-field="keywords"]').value
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean),
    instruction: row.querySelector('[data-field="instruction"]').value.trim()
  })).filter((profile) => profile.id && profile.name && profile.instruction);
}

async function load() {
  const response = await send({ type: "APS_GET_STATE" });
  if (!response?.state) {
    setStatus(response?.error || "Falha ao carregar.", "error");
    return;
  }
  const state = response.state;
  currentProfiles = state.profiles || [];
  document.getElementById("showIndicator").checked = state.showIndicator !== false;
  document.getElementById("autoNewChatAfterClean").checked = state.autoNewChatAfterClean !== false;
  document.getElementById("activeMemory").value = state.activeMemory || "";
  renderProfiles(currentProfiles);
}

document.getElementById("addProfile").addEventListener("click", () => {
  currentProfiles = [...collectProfiles(), {
    id: `perfil-${Date.now().toString(36)}`,
    name: "Novo especialista",
    capability: "Modelo equilibrado",
    description: "",
    keywords: [],
    instruction: "Resolva o pedido com clareza, valide premissas e entregue uma saida utilizavel."
  }];
  renderProfiles(currentProfiles);
});

document.getElementById("profiles").addEventListener("click", (event) => {
  const index = event.target?.dataset?.remove;
  if (index === undefined) return;
  currentProfiles = collectProfiles();
  currentProfiles.splice(Number(index), 1);
  renderProfiles(currentProfiles);
});

document.getElementById("save").addEventListener("click", async () => {
  const profiles = collectProfiles();
  if (!profiles.length) {
    setStatus("Mantenha pelo menos um perfil valido.", "error");
    return;
  }
  setStatus("Salvando...", "neutral");
  const response = await send({
    type: "APS_UPDATE_SETTINGS",
    patch: {
      profiles,
      showIndicator: document.getElementById("showIndicator").checked,
      autoNewChatAfterClean: document.getElementById("autoNewChatAfterClean").checked,
      activeMemory: document.getElementById("activeMemory").value
    }
  });
  if (!response?.state) {
    setStatus(response?.error || "Nao foi possivel salvar.", "error");
    return;
  }
  currentProfiles = response.state.profiles;
  document.getElementById("activeMemory").value = response.state.activeMemory || "";
  renderProfiles(currentProfiles);
  setStatus("Salvo. Os chats abertos foram atualizados.", "success");
});

document.getElementById("clearMemory").addEventListener("click", async () => {
  if (!confirm("Apagar a memoria consolidada e os registros da sessao?")) return;
  const response = await send({ type: "APS_CLEAR_MEMORY" });
  if (response?.state) {
    document.getElementById("activeMemory").value = "";
    setStatus("Memoria apagada.", "success");
  }
});

void load();
