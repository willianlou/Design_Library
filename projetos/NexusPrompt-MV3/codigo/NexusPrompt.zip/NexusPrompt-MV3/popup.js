let currentState = null;

function formatCount(value) {
  const number = Number(value) || 0;
  if (number < 1000) return String(number);
  return `${(number / 1000).toFixed(number >= 10000 ? 0 : 1)}k`;
}

function render(state) {
  currentState = state;
  const route = state.lastRoute || {
    profileName: "Deteccao automatica",
    capability: "Aguardando o proximo prompt"
  };
  const evaluation = state.lastEvaluation;
  const responseEvaluation = state.lastResponseEvaluation;
  const optimizedBenchmark = state.responseBenchmarks?.optimized || { count: 0, average: 0 };
  const baselineBenchmark = state.responseBenchmarks?.baseline || { count: 0, average: 0 };
  const button = document.getElementById("powerButton");

  document.body.dataset.enabled = state.enabled ? "true" : "false";
  button.dataset.enabled = state.enabled ? "true" : "false";
  document.getElementById("powerLabel").textContent = state.enabled ? "Automatico ativo" : "Desativado";
  document.getElementById("statusDetail").textContent = state.enabled
    ? "Escreva normalmente. O perfil, a rota e a validacao sao aplicados no momento do envio."
    : "Os prompts passam sem alteracao. Use este botao ou /ativar para religar.";
  document.getElementById("activeAgent").textContent = route.profileName;
  document.getElementById("activeRoute").textContent = route.capability;
  document.getElementById("validationScore").textContent = responseEvaluation
    ? `Resposta ${responseEvaluation.score}/100`
    : evaluation
      ? `Estrutura ${evaluation.scoreAfter}/100`
    : "Automatico";
  document.getElementById("benchmarkDetail").textContent = optimizedBenchmark.count && baselineBenchmark.count
    ? `Media com filtro ${optimizedBenchmark.average}/100 contra ${baselineBenchmark.average}/100 sem filtro (${optimizedBenchmark.average - baselineBenchmark.average >= 0 ? "+" : ""}${optimizedBenchmark.average - baselineBenchmark.average} pontos).`
    : `Medicao em andamento: ${optimizedBenchmark.count} resposta(s) filtrada(s) e ${baselineBenchmark.count} sem filtro.`;
  document.getElementById("optimizedCount").textContent = formatCount(state.stats?.optimizedPrompts);
  document.getElementById("consolidatedCount").textContent = formatCount(state.stats?.consolidatedChats);
  document.getElementById("memorySize").textContent = formatCount(state.activeMemory?.length);
  document.getElementById("reductionValue").textContent = state.lastConsolidation
    ? `${state.lastConsolidation.reduction}% de reducao estimada`
    : "Ainda nao executada";
}

async function load() {
  const response = await chrome.runtime.sendMessage({ type: "APS_GET_STATE" });
  if (!response?.state) {
    document.getElementById("statusDetail").textContent = response?.error || "Nao foi possivel ler a extensao.";
    return;
  }
  render(response.state);
}

document.getElementById("powerButton").addEventListener("click", async () => {
  if (!currentState) return;
  const response = await chrome.runtime.sendMessage({
    type: "APS_SET_ENABLED",
    enabled: !currentState.enabled
  });
  if (response?.state) render(response.state);
});

void load();
