import { getDomainFromUrl, calculateScore, normalizeDomain } from '../utils/domain-utils.js';
import { ESSENTIAL_DOMAINS, EXCLUDE_FROM_AUTO_WHITELIST } from '../utils/constants.js';

console.log('🛡️ PhishGuard Security Service Worker iniciado');

let autoWhitelist = new Set();
let userWhitelist = [];
let blacklistSet = new Set();

async function loadLists() {
  try {
    const whitelistResp = await fetch(chrome.runtime.getURL('utils/whitelist.json'));
    const whitelistData = await whitelistResp.json();
    (whitelistData.domains || []).forEach(d => {
      const domain = normalizeDomain(d);
      if (!EXCLUDE_FROM_AUTO_WHITELIST.includes(domain)) {
        autoWhitelist.add(domain);
      }
    });
    console.log(`✅ Whitelist automática: ${autoWhitelist.size} domínios`);

    const blacklistResp = await fetch(chrome.runtime.getURL('utils/blacklist.json'));
    const blacklistData = await blacklistResp.json();
    (blacklistData.domains || []).forEach(d => {
      blacklistSet.add(normalizeDomain(d));
    });
    console.log(`❌ Blacklist: ${blacklistSet.size} domínios`);
  } catch (err) {
    console.warn('⚠️ Erro ao carregar listas:', err);
  }

  chrome.storage.local.get(['userWhitelist'], (result) => {
    userWhitelist = (result.userWhitelist || []).map(d => normalizeDomain(d));
    console.log(`👤 User whitelist: ${userWhitelist.length} domínios`);
  });
}

function isWhitelisted(domain) {
  if (!domain) return false;
  const d = normalizeDomain(domain);
  return ESSENTIAL_DOMAINS.includes(d) || autoWhitelist.has(d) || userWhitelist.includes(d);
}

function isBlacklisted(domain) {
  if (!domain) return false;
  return blacklistSet.has(normalizeDomain(domain));
}

function isRestrictedPage(url) {
  return url.startsWith('chrome://') ||
         url.startsWith('chrome-extension://') ||
         url.startsWith('about:') ||
         url.includes('chrome.google.com');
}

function redirectToAnalysis(tabId, url, score) {
  chrome.tabs.update(tabId, {
    url: chrome.runtime.getURL('pages/analyzing.html') +
         `?url=${encodeURIComponent(url)}&score=${score}`
  });
}

function redirectToBlocked(tabId, url, reason, score) {
  chrome.tabs.update(tabId, {
    url: chrome.runtime.getURL('pages/blocked.html') +
         `?url=${encodeURIComponent(url)}&reason=${reason}&score=${score}`
  });
}

function analyzeAndBlock(tabId, url) {
  if (!url || isRestrictedPage(url)) return false;
  const domain = getDomainFromUrl(url);
  if (!domain) return false;
  const domainClean = normalizeDomain(domain);

  if (ESSENTIAL_DOMAINS.includes(domainClean)) {
    console.log(`✅ Essencial: ${domain}`);
    return false;
  }
  if (isWhitelisted(domain)) {
    console.log(`✅ Whitelist: ${domain}`);
    return false;
  }
  if (isBlacklisted(domain)) {
    console.log(`🚫 Blacklist: ${domain}`);
    redirectToBlocked(tabId, url, 'blacklist', 0);
    return true;
  }
  const score = calculateScore(domain, url, false);
  console.log(`🔍 Análise: ${domain} | Score: ${score}`);
  redirectToAnalysis(tabId, url, score);
  return true;
}

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId === 0) {
    analyzeAndBlock(details.tabId, details.url);
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'checkDomain') {
    const domain = request.domain || '';
    const d = normalizeDomain(domain);
    sendResponse({
      whitelisted: isWhitelisted(d),
      blacklisted: isBlacklisted(d),
      userWhitelisted: userWhitelist.includes(d)
    });
    return true;
  }

  if (request.action === 'addToWhitelist') {
    const domain = request.domain || '';
    const clean = normalizeDomain(domain);
    if (clean && !userWhitelist.includes(clean)) {
      userWhitelist.push(clean);
      chrome.storage.local.set({ userWhitelist }, () => {
        sendResponse({ success: true });
      });
    } else {
      sendResponse({ success: false, message: 'Domínio já está na whitelist' });
    }
    return true;
  }

  if (request.action === 'userDecision') {
    const { url, decision } = request;
    const domain = getDomainFromUrl(url);
    const clean = domain ? normalizeDomain(domain) : null;
    if (decision === 'allow') {
      if (clean && !userWhitelist.includes(clean)) {
        userWhitelist.push(clean);
        chrome.storage.local.set({ userWhitelist });
      }
      chrome.tabs.update(sender.tab.id, { url });
      sendResponse({ success: true });
    } else if (decision === 'block') {
      chrome.tabs.update(sender.tab.id, {
        url: chrome.runtime.getURL('pages/blocked.html') +
             `?url=${encodeURIComponent(url)}&reason=user_blocked`
      });
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false, message: 'Decisão inválida' });
    }
    return true;
  }
  return true;
});

chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local' && changes.userWhitelist) {
    userWhitelist = (changes.userWhitelist.newValue || []).map(d => normalizeDomain(d));
    console.log(`🔄 User whitelist atualizada: ${userWhitelist.length}`);
  }
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('🛡️ PhishGuard Security instalado!');
  loadLists();
});

loadLists();