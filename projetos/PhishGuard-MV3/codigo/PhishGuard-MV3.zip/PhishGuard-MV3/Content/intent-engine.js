(function() {
  'use strict';
  const restricted = ['chrome://', 'chrome-extension://', 'about:'];
  if (restricted.some(p => location.href.startsWith(p))) return;

  function injectBadge(type, message) {
    const existing = document.querySelector('.phishguard-badge');
    if (existing) existing.remove();

    const badge = document.createElement('div');
    badge.className = 'phishguard-badge';
    const colors = {
      trusted: { bg: 'rgba(52,211,153,0.9)', color: '#fff', icon: '🛡️' },
      unknown: { bg: 'rgba(251,191,36,0.9)', color: '#1a1a2e', icon: '⚠️' },
      dangerous: { bg: 'rgba(239,68,68,0.9)', color: '#fff', icon: '🚫' }
    };
    const style = colors[type] || colors.unknown;
    Object.assign(badge.style, {
      position: 'fixed',
      bottom: '20px',
      right: '20px',
      background: style.bg,
      color: style.color,
      padding: '10px 16px',
      borderRadius: '8px',
      fontSize: '14px',
      fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif',
      boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
      zIndex: 999999,
      cursor: 'default',
      animation: 'slideIn 0.3s ease',
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    });
    badge.innerHTML = `<span>${style.icon}</span> ${message}`;
    document.body.appendChild(badge);

    if (!document.querySelector('#phishguard-style')) {
      const styleEl = document.createElement('style');
      styleEl.id = 'phishguard-style';
      styleEl.textContent = `
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
      `;
      document.head.appendChild(styleEl);
    }
  }

  function waitForElement(selector, callback, maxAttempts = 20) {
    let attempts = 0;
    const check = () => {
      attempts++;
      if (document.querySelector(selector)) {
        callback();
        return;
      }
      if (attempts >= maxAttempts) {
        callback();
        return;
      }
      setTimeout(check, 200);
    };
    check();
  }

  waitForElement('body', () => {
    chrome.runtime.sendMessage({
      action: 'checkDomain',
      domain: location.hostname
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.debug('Erro ao verificar domínio:', chrome.runtime.lastError);
        return;
      }
      if (response) {
        if (response.whitelisted) {
          injectBadge('trusted', 'Site Confiável');
        } else if (response.blacklisted) {
          injectBadge('dangerous', 'Site Perigoso');
        } else {
          injectBadge('unknown', 'Site Desconhecido');
        }
      }
    });
  });
})();