(function() {
  'use strict';

  const params = new URLSearchParams(location.search);
  const targetUrl = params.get('url') || 'URL não fornecida';
  const initialScore = parseInt(params.get('score'), 10) || 50;

  let score = Math.min(Math.max(initialScore, 0), 100);
  let reasons = [];
  let analysisComplete = false;
  let userWhitelist = [];
  let testResults = [];

  const elements = {
    url: document.getElementById('targetUrl'),
    progressNumber: document.getElementById('progressNumber'),
    progressStatus: document.getElementById('progressStatus'),
    progressLabel: document.getElementById('progressLabel'),
    progressRing: document.getElementById('progressRing'),
    resultSection: document.getElementById('resultSection'),
    resultIcon: document.getElementById('resultIcon'),
    resultTitle: document.getElementById('resultTitle'),
    resultDescription: document.getElementById('resultDescription'),
    finalScore: document.getElementById('finalScore'),
    finalScoreStatus: document.getElementById('finalScoreStatus'),
    reasons: document.getElementById('reasons'),
    tipText: document.getElementById('tipText'),
    continueBtn: document.getElementById('continueBtn'),
    addToWhitelistBtn: document.getElementById('addToWhitelistBtn'),
    statusBadge: document.getElementById('statusBadge'),
    copyBtn: document.getElementById('copyBtn'),
    goBackBtn: document.getElementById('goBackBtn')
  };

  const tips = [
    'Verifique sempre o domínio principal antes de inserir dados sensíveis.',
    'Desconfie de URLs com muitos subdomínios ou caracteres estranhos.',
    'Sites seguros geralmente usam HTTPS e têm certificados válidos.',
    'Nunca forneça senhas ou informações pessoais em sites não confiáveis.',
    'Se algo parecer suspeito, feche a página e verifique a URL.'
  ];

  function getDomainFromUrl(url) {
    try { return new URL(url).hostname; } catch { return null; }
  }

  function normalizeDomain(domain) {
    if (!domain) return domain;
    return domain.replace(/^www\./, '').toLowerCase().trim();
  }

  function showToast(message, type = 'info') {
    const existing = document.querySelector('.custom-toast');
    if (existing) existing.remove();
    const toast = document.createElement('div');
    toast.className = 'custom-toast';
    const colors = {
      info: 'rgba(0,0,0,0.9)',
      success: 'rgba(52,211,153,0.9)',
      error: 'rgba(239,68,68,0.9)'
    };
    Object.assign(toast.style, {
      position: 'fixed',
      bottom: '100px',
      left: '50%',
      transform: 'translateX(-50%)',
      background: colors[type] || colors.info,
      color: '#fff',
      padding: '16px 24px',
      borderRadius: '12px',
      fontSize: '18px',
      fontWeight: '600',
      zIndex: 999999,
      maxWidth: '90%',
      textAlign: 'center',
      animation: 'fadeInUp 0.3s ease',
      boxShadow: '0 8px 32px rgba(0,0,0,0.5)'
    });
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.5s';
      setTimeout(() => toast.remove(), 500);
    }, 3000);
  }

  function loadUserWhitelist() {
    chrome.storage.local.get(['userWhitelist'], (result) => {
      userWhitelist = (result.userWhitelist || []).map(d => normalizeDomain(d));
      const domain = getDomainFromUrl(targetUrl);
      if (domain && userWhitelist.includes(normalizeDomain(domain))) {
        score = 100;
        reasons.push('✅ Site na sua lista de confiáveis');
        completeAnalysis();
      } else {
        analyzeSite();
      }
    });
  }

  function updateProgress(value) {
    const circumference = 339.292;
    const offset = circumference - (value / 100) * circumference;
    elements.progressRing.style.strokeDashoffset = offset;
    elements.progressNumber.textContent = Math.round(value) + '%';
    const statuses = ['Iniciando...', 'Analisando domínio...', 'Verificando segurança...', 'Quase lá...', 'Finalizando...'];
    const idx = Math.min(Math.floor(value / 25), statuses.length - 1);
    elements.progressStatus.textContent = statuses[idx] || 'Analisando...';
  }

  function analyzeSite() {
    updateProgress(0);
    elements.tipText.textContent = tips[Math.floor(Math.random() * tips.length)];

    let step = 0;
    const totalSteps = 8;
    const interval = setInterval(() => {
      step++;
      const progress = Math.min((step / totalSteps) * 100, 100);
      updateProgress(progress);
      const labels = [
        '🔍 Verificando domínio...',
        '⚠️ Analisando padrões suspeitos...',
        '📁 Verificando extensões...',
        '🛡️ Checando reputação...',
        '📊 Calculando pontuação...',
        '🔎 Verificando similaridade com sites conhecidos...',
        '📋 Gerando relatório...',
        '✅ Análise concluída!'
      ];
      elements.progressLabel.textContent = labels[step - 1] || 'Analisando...';
      if (step >= totalSteps) {
        clearInterval(interval);
        completeAnalysis();
      }
    }, 500);
  }

  async function loadTestResults() {
    try {
      const module = await import('../utils/domain-utils.js');
      const domain = getDomainFromUrl(targetUrl);
      testResults = module.getTestResults(domain, targetUrl);
    } catch (e) {
      console.warn('Erro ao carregar testes:', e);
      testResults = [];
    }
  }

  function completeAnalysis() {
    analysisComplete = true;
    const domain = getDomainFromUrl(targetUrl);
    // Carrega os testes assincronamente
    loadTestResults().then(() => {
      // Os testes já foram carregados
    });

    if (score >= 80) reasons.push('✅ Domínio seguro - nenhuma ameaça detectada');
    else if (score >= 60) reasons.push('ℹ️ Domínio não verificado - proceda com cautela');
    else if (score >= 40) reasons.push('⚠️ Padrões suspeitos detectados no domínio');
    else reasons.push('🚫 Domínio com características perigosas');

    if (score < 40) reasons.push('⚠️ Considere não prosseguir para este site');
    if (reasons.length === 0) reasons.push('ℹ️ Nenhuma ameaça específica detectada');

    showResult(score >= 70 ? 'safe' : score >= 40 ? 'warning' : 'danger');
  }

  function showResult(type) {
    elements.resultSection.style.display = 'block';
    elements.finalScore.textContent = score;
    elements.reasons.innerHTML = '';
    reasons.forEach(text => {
      const div = document.createElement('div');
      div.className = 'reason-item';
      const icon = text.includes('✅') ? '✅' : text.includes('❌') ? '❌' : text.includes('⚠️') ? '⚠️' : 'ℹ️';
      div.innerHTML = `<span class="reason-icon">${icon}</span><span class="reason-text">${text.replace(/[✅❌ℹ️⚠️]\s*/, '')}</span>`;
      elements.reasons.appendChild(div);
    });

    const configs = {
      safe: {
        icon: '✅',
        title: 'Site Seguro!',
        desc: 'Este site parece seguro para navegar.',
        status: '✅ Seguro',
        color: '#34d399',
        badge: 'Seguro',
        btnClass: 'btn-primary',
        btnText: '✅ Prosseguir para o Site'
      },
      warning: {
        icon: '⚠️',
        title: 'Cuidado!',
        desc: 'Este site apresenta características suspeitas.',
        status: '⚠️ Cuidado',
        color: '#fbbf24',
        badge: 'Cuidado',
        btnClass: 'btn-primary',
        btnText: '⚠️ Prosseguir com Cuidado'
      },
      danger: {
        icon: '🚫',
        title: 'PERIGO!',
        desc: 'Este site está na lista negra! NÃO RECOMENDAMOS prosseguir.',
        status: '🚫 Perigoso',
        color: '#ef4444',
        badge: 'Perigoso',
        btnClass: 'btn-danger',
        btnText: '🚫 Prosseguir mesmo assim'
      }
    };

    const cfg = configs[type] || configs.safe;
    elements.resultIcon.textContent = cfg.icon;
    elements.resultTitle.textContent = cfg.title;
    elements.resultDescription.textContent = cfg.desc;
    elements.finalScoreStatus.textContent = cfg.status;
    elements.finalScoreStatus.style.background = cfg.color + '33';
    elements.finalScoreStatus.style.color = cfg.color;
    elements.progressRing.style.stroke = cfg.color;
    elements.statusBadge.innerHTML = `<span class="dot" style="background:${cfg.color};"></span> ${cfg.badge}`;
    elements.statusBadge.style.color = cfg.color;
    elements.continueBtn.disabled = false;
    elements.continueBtn.className = `btn ${cfg.btnClass}`;
    elements.continueBtn.innerHTML = `<span class="btn-text">${cfg.btnText}</span><span class="btn-icon">→</span>`;

    const domain = getDomainFromUrl(targetUrl);
    const normalized = domain ? normalizeDomain(domain) : null;
    if (normalized && !userWhitelist.includes(normalized) && type !== 'danger') {
      elements.addToWhitelistBtn.style.display = 'block';
    } else {
      elements.addToWhitelistBtn.style.display = 'none';
    }

    // Exibe testes realizados (espera carregar)
    if (testResults.length > 0) {
      renderTests();
    } else {
      // Se ainda não carregou, tenta novamente após um curto tempo
      setTimeout(() => {
        if (testResults.length > 0) renderTests();
        else {
          // Fallback: tenta carregar diretamente
          loadTestResults().then(() => {
            if (testResults.length > 0) renderTests();
          });
        }
      }, 500);
    }
  }

  function renderTests() {
    const existing = document.querySelector('.test-results');
    if (existing) existing.remove();

    const testContainer = document.createElement('div');
    testContainer.className = 'test-results';
    testContainer.innerHTML = '<h3>🔍 Testes realizados</h3>';
    const list = document.createElement('ul');
    testResults.forEach(test => {
      const li = document.createElement('li');
      const icon = test.passed ? '✅' : '❌';
      li.innerHTML = `<span>${icon}</span> <span style="flex:1;">${test.name}</span> <span style="color:${test.passed ? '#34d399' : '#ef4444'};">${test.passed ? 'Aprovado' : 'Reprovado'}</span>`;
      list.appendChild(li);
    });
    testContainer.appendChild(list);
    elements.reasons.parentNode.appendChild(testContainer);
  }

  function copyUrl() {
    navigator.clipboard.writeText(targetUrl).then(() => {
      showToast('✅ URL copiada!', 'success');
    }).catch(() => showToast('❌ Erro ao copiar', 'error'));
  }

  function goBack() {
    window.history.back();
  }

  function continueToSite() {
    if (!analysisComplete) return;
    if (score < 40 && !confirm(`⚠️ ATENÇÃO: Este site tem pontuação ${score}%. Tem certeza que deseja prosseguir?`)) {
      return;
    }
    chrome.runtime.sendMessage({
      action: 'userDecision',
      url: targetUrl,
      decision: 'allow'
    }, () => {
      if (chrome.runtime.lastError) {
        console.warn('Erro ao enviar decisão:', chrome.runtime.lastError);
      }
      window.location.href = targetUrl;
    });
  }

  function addToWhitelist() {
    const domain = getDomainFromUrl(targetUrl);
    if (!domain) return;
    const normalized = normalizeDomain(domain);
    chrome.runtime.sendMessage({
      action: 'addToWhitelist',
      domain: normalized
    }, (response) => {
      if (chrome.runtime.lastError) {
        showToast('❌ Erro ao adicionar', 'error');
        return;
      }
      if (response && response.success) {
        showToast('✅ Domínio adicionado à lista de confiáveis!', 'success');
        elements.addToWhitelistBtn.style.display = 'none';
        userWhitelist.push(normalized);
      } else {
        showToast(response.message || '❌ Falha ao adicionar', 'error');
      }
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    elements.url.textContent = targetUrl;
    elements.copyBtn.addEventListener('click', copyUrl);
    elements.goBackBtn.addEventListener('click', goBack);
    elements.continueBtn.addEventListener('click', continueToSite);
    elements.addToWhitelistBtn.addEventListener('click', addToWhitelist);
    loadUserWhitelist();
  });
})();