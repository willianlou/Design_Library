(function() {
  const params = new URLSearchParams(location.search);
  const url = params.get('url') || 'URL não fornecida';
  const score = parseInt(params.get('score'), 10) || 100;
  const reason = params.get('reason') || 'blacklist';

  document.getElementById('blockedUrl').textContent = url;
  document.getElementById('scoreNumber').textContent = Math.min(score, 100);

  const scoreCircle = document.getElementById('scoreCircle');
  const scoreText = document.getElementById('scoreText');
  let color = '#ef4444';
  let label = 'Risco Crítico';
  if (score < 30) { color = '#34d399'; label = 'Risco Baixo'; }
  else if (score < 60) { color = '#f59e0b'; label = 'Risco Médio'; }
  scoreCircle.style.borderColor = color;
  scoreText.textContent = label;
  scoreText.style.color = color;

  let reasonText = 'Ameaça detectada';
  let reasonDetails = [];
  if (reason === 'blacklist') {
    reasonText = 'Domínio presente na lista negra';
    reasonDetails = ['Este site está catalogado como malicioso.', 'Pode conter malware, phishing ou conteúdo fraudulento.'];
  } else if (reason === 'user_blocked') {
    reasonText = 'Bloqueado pelo usuário';
    reasonDetails = ['Você optou por não acessar este site.', 'Pode revisar a decisão a qualquer momento.'];
  } else {
    reasonText = 'Acesso bloqueado por segurança';
    reasonDetails = ['A análise indicou risco elevado.', 'Recomendamos não prosseguir.'];
  }
  document.getElementById('reasonText').textContent = reasonText;
  const detailsContainer = document.getElementById('reasonDetails');
  reasonDetails.forEach(line => {
    const p = document.createElement('p');
    p.textContent = line;
    detailsContainer.appendChild(p);
  });

  document.getElementById('backBtn').addEventListener('click', () => window.history.back());
  document.getElementById('proceedBtn').addEventListener('click', () => {
    if (confirm('Atenção: Este site foi bloqueado por segurança. Deseja realmente prosseguir?')) {
      chrome.tabs.update({ url: url });
    }
  });
})();