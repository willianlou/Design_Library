// utils/BlacklistManager.js
// Gerencia a blacklist e padrões suspeitos.

export class BlacklistManager {
  constructor() {
    this.blacklist = new Set();
    this.suspiciousPatterns = [];
    this.suspiciousTLDs = [];
    this.initialized = false;
    this.loadBlacklist();
  }

  async loadBlacklist() {
    try {
      const response = await fetch(chrome.runtime.getURL('utils/blacklist.json'));
      if (!response.ok) throw new Error('HTTP ' + response.status);
      const data = await response.json();
      const domains = data.domains || [];
      for (const d of domains) {
        this.blacklist.add(d.toLowerCase().trim());
      }
      this.suspiciousPatterns = data.patterns || [
        'crack', 'serial', 'keygen', 'hack', 'pirata', 'malware', 'virus',
        'trojan', 'ransom', 'phish'
      ];
      this.suspiciousTLDs = data.tlds || [
        '.top', '.xyz', '.club', '.online', '.site', '.live',
        '.stream', '.download', '.host', '.space', '.pro', '.work',
        '.click', '.link', '.win', '.bid', '.date', '.loan', '.men',
        '.mom', '.party', '.review', '.trade', '.webcam', '.wang'
      ];
      console.log(`[Blacklist] Carregada: ${this.blacklist.size} domínios, ${this.suspiciousPatterns.length} padrões, ${this.suspiciousTLDs.length} TLDs`);
    } catch (error) {
      console.warn('[Blacklist] Falha ao carregar, usando defaults:', error);
      this.setDefaultBlacklist();
    }
    this.initialized = true;
  }

  setDefaultBlacklist() {
    const defaults = [
      'malware.com', 'phishing-site.net', 'virus-download.org',
      'hack-tool.com', 'crack-site.net', 'keygen-download.com'
    ];
    for (const d of defaults) {
      this.blacklist.add(d);
    }
    this.suspiciousPatterns = ['crack', 'serial', 'keygen', 'hack', 'pirata', 'malware', 'virus'];
    this.suspiciousTLDs = ['.top', '.xyz', '.club', '.online', '.site', '.live'];
  }

  isBlacklisted(domain) {
    if (!domain || !this.initialized) return false;
    const clean = domain.toLowerCase().trim();
    if (this.blacklist.has(clean)) return true;
    // Verificar padrões no domínio
    for (const pattern of this.suspiciousPatterns) {
      if (clean.includes(pattern)) return true;
    }
    // Verificar TLD
    for (const tld of this.suspiciousTLDs) {
      if (clean.endsWith(tld)) return true;
    }
    return false;
  }

  getThreatLevel(domain) {
    if (!domain) return 'unknown';
    const clean = domain.toLowerCase().trim();
    if (this.blacklist.has(clean)) return 'critical';
    for (const pattern of this.suspiciousPatterns) {
      if (clean.includes(pattern)) return 'high';
    }
    for (const tld of this.suspiciousTLDs) {
      if (clean.endsWith(tld)) return 'medium';
    }
    return 'low';
  }
}