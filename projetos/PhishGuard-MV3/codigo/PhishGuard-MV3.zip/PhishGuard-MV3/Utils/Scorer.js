// utils/Scorer.js
// Módulo responsável por calcular a pontuação de risco com base em heurísticas locais.

export class Scorer {
  /**
   * Calcula score de risco (0-100) para uma URL.
   * @param {string} url - URL completa.
   * @param {string} domain - Domínio extraído.
   * @param {Set} blacklist - Conjunto de domínios na blacklist.
   * @param {Set} whitelist - Conjunto de domínios na whitelist.
   * @returns {number} Score de 0 a 100.
   */
  static calculate(url, domain, blacklist, whitelist) {
    let score = 0;

    // 1. Se estiver na whitelist, retorna 100 (seguro)
    if (whitelist && whitelist.has(domain)) {
      return 100;
    }

    // 2. Se estiver na blacklist, penalidade máxima
    if (blacklist && blacklist.has(domain)) {
      return 0; // ou 100? Vamos usar 0 como perigoso.
    }

    // 3. Heurísticas estruturais
    const domainParts = domain.split('.');
    const mainDomain = domainParts.slice(-2).join('.');

    // a) Domínio muito longo
    if (domain.length > 35) score += 15;

    // b) Muitos subdomínios (>3)
    if (domainParts.length > 4) score += 10;

    // c) Contém números no domínio principal
    if (/\d/.test(mainDomain)) score += 10;

    // d) Contém caracteres especiais (traços, underline)
    if (/[-_]/.test(domain)) score += 5;

    // e) É um IP (ex: 192.168.1.1)
    if (/^(\d{1,3}\.){3}\d{1,3}$/.test(domain)) score += 30;

    // 4. Heurísticas de URL
    try {
      const urlObj = new URL(url);
      // f) Protocolo não HTTPS (http)
      if (urlObj.protocol !== 'https:') score += 20;

      // g) Presença de caracteres estranhos na URL
      if (/[^a-zA-Z0-9\-._~:/?#\[\]@!$&'()*+,;=]/.test(url)) score += 5;

      // h) Redirecionamentos excessivos (se houver muitos parâmetros)
      if (urlObj.search.length > 50) score += 10;

    } catch (e) {
      // URL inválida – penaliza
      score += 20;
    }

    // 5. Palavras suspeitas no domínio ou URL
    const suspiciousWords = [
      'crack', 'serial', 'keygen', 'hack', 'pirata', 'malware', 'virus',
      'trojan', 'ransom', 'phish', 'download-gratis', 'gratis', 'login',
      'secure', 'verify', 'account', 'update', 'confirm', 'bank', 'banc',
      'boleto', 'pagamento', 'seguro', 'sorte', 'promoção', 'promocao',
      'gratuito', 'ganhe', 'click', 'clique', 'oferta'
    ];

    for (const word of suspiciousWords) {
      if (domain.includes(word) || url.toLowerCase().includes(word)) {
        score += 10;
        break; // basta uma palavra
      }
    }

    // 6. TLDs suspeitos
    const suspiciousTLDs = [
      '.top', '.xyz', '.club', '.online', '.site', '.live',
      '.stream', '.download', '.host', '.space', '.pro', '.work',
      '.click', '.link', '.win', '.bid', '.date', '.loan', '.men',
      '.mom', '.party', '.review', '.trade', '.webcam', '.wang'
    ];

    for (const tld of suspiciousTLDs) {
      if (domain.endsWith(tld)) {
        score += 15;
        break;
      }
    }

    // 7. Verificação de typosquatting (similaridade com domínios conhecidos)
    const knownDomains = [
      'google.com', 'gmail.com', 'youtube.com', 'facebook.com',
      'microsoft.com', 'outlook.com', 'github.com', 'stackoverflow.com',
      'wikipedia.org', 'amazon.com', 'netflix.com', 'twitter.com',
      'instagram.com', 'whatsapp.com', 'linkedin.com', 'reddit.com',
      'live.com', 'office.com', 'apple.com', 'icloud.com'
    ];

    // Função simples de distância de Levenshtein (adaptada para domínios)
    function levenshtein(a, b) {
      const matrix = [];
      for (let i = 0; i <= b.length; i++) {
        matrix[i] = [i];
      }
      for (let j = 0; j <= a.length; j++) {
        matrix[0][j] = j;
      }
      for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
          if (b[i-1] === a[j-1]) {
            matrix[i][j] = matrix[i-1][j-1];
          } else {
            matrix[i][j] = Math.min(
              matrix[i-1][j-1] + 1,
              matrix[i][j-1] + 1,
              matrix[i-1][j] + 1
            );
          }
        }
      }
      return matrix[b.length][a.length];
    }

    // Comparar domínio principal com domínios conhecidos
    for (const known of knownDomains) {
      const dist = levenshtein(mainDomain, known);
      if (dist > 0 && dist <= 2) {
        // Similar, mas não idêntico – provável typosquatting
        score += 20;
        break;
      }
    }

    // 8. Se o domínio tiver mais de 2 subdomínios e alguma palavra suspeita, pontuação extra
    if (domainParts.length > 3 && suspiciousWords.some(w => domain.includes(w))) {
      score += 10;
    }

    // Garantir que o score fique entre 0 e 100
    return Math.min(Math.max(score, 0), 100);
  }
}