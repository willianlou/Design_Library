// utils/WhitelistManager.js
// Gerencia a whitelist global e do usuário.

export class WhitelistManager {
  constructor() {
    this.globalWhitelist = new Set();
    this.userWhitelist = new Set();
    this.essentialDomains = new Set([
      'google.com', 'gmail.com', 'accounts.google.com',
      'youtube.com', 'microsoft.com', 'live.com', 'outlook.com',
      'github.com', 'stackoverflow.com', 'wikipedia.org',
      'amazon.com', 'netflix.com', 'twitter.com', 'instagram.com',
      'linkedin.com', 'reddit.com', 'apple.com', 'icloud.com',
      'whatsapp.com', 'facebook.com'
    ]);
    this.excludeFromGlobal = new Set([
      'google.com', 'gmail.com', 'youtube.com',
      'accounts.google.com', 'mail.google.com',
      'drive.google.com', 'photos.google.com',
      'calendar.google.com', 'maps.google.com'
    ]);
    this.initialized = false;
    this.loadGlobalWhitelist();
    this.loadUserWhitelist();
  }

  async loadGlobalWhitelist() {
    try {
      const response = await fetch(chrome.runtime.getURL('utils/whitelist.json'));
      if (!response.ok) throw new Error('HTTP ' + response.status);
      const data = await response.json();
      const domains = data.domains || [];
      for (const d of domains) {
        const clean = d.toLowerCase().trim();
        if (!this.excludeFromGlobal.has(clean)) {
          this.globalWhitelist.add(clean);
        }
      }
      console.log(`[Whitelist] Global carregada: ${this.globalWhitelist.size} domínios`);
    } catch (error) {
      console.warn('[Whitelist] Falha ao carregar whitelist global:', error);
    }
    this.initialized = true;
  }

  loadUserWhitelist() {
    chrome.storage.local.get(['userWhitelist'], (result) => {
      const list = result.userWhitelist || [];
      for (const d of list) {
        this.userWhitelist.add(d.toLowerCase().trim());
      }
      console.log(`[Whitelist] Usuário: ${this.userWhitelist.size} domínios`);
    });
  }

  isWhitelisted(domain) {
    if (!domain) return false;
    const clean = domain.toLowerCase().trim();
    if (this.essentialDomains.has(clean)) return true;
    if (this.globalWhitelist.has(clean)) return true;
    if (this.userWhitelist.has(clean)) return true;
    return false;
  }

  addUserWhitelist(domain) {
    if (!domain) return false;
    const clean = domain.toLowerCase().trim();
    if (!this.userWhitelist.has(clean)) {
      this.userWhitelist.add(clean);
      // Persistir no storage
      chrome.storage.local.get(['userWhitelist'], (result) => {
        const list = result.userWhitelist || [];
        if (!list.includes(clean)) {
          list.push(clean);
          chrome.storage.local.set({ userWhitelist: list });
        }
      });
      return true;
    }
    return false;
  }

  removeUserWhitelist(domain) {
    if (!domain) return false;
    const clean = domain.toLowerCase().trim();
    if (this.userWhitelist.has(clean)) {
      this.userWhitelist.delete(clean);
      chrome.storage.local.get(['userWhitelist'], (result) => {
        const list = result.userWhitelist || [];
        const index = list.indexOf(clean);
        if (index !== -1) {
          list.splice(index, 1);
          chrome.storage.local.set({ userWhitelist: list });
        }
      });
      return true;
    }
    return false;
  }

  getStats() {
    return {
      global: this.globalWhitelist.size,
      user: this.userWhitelist.size,
      essential: this.essentialDomains.size,
      total: this.globalWhitelist.size + this.userWhitelist.size + this.essentialDomains.size
    };
  }
}