export const SUSPICIOUS_TLDS = [
  '.top', '.xyz', '.club', '.online', '.site', '.live',
  '.stream', '.download', '.host', '.space', '.click',
  '.loan', '.win', '.bid', '.trade', '.webcam'
];

export const SUSPICIOUS_PATTERNS = [
  'crack', 'serial', 'keygen', 'hack', 'pirata', 'malware',
  'virus', 'trojan', 'ransom', 'phish', 'gratis', 'download-gratis',
  'seguro', 'verificar', 'atualizar', 'login-seguro', 'conta-bancaria'
];

export const DANGEROUS_EXTENSIONS = [
  '.exe', '.msi', '.bat', '.cmd', '.scr', '.vbs', '.com', '.pif'
];

export const TRUSTED_DOMAINS = [
  'google.com', 'gmail.com', 'accounts.google.com',
  'youtube.com', 'microsoft.com', 'live.com', 'outlook.com',
  'github.com', 'stackoverflow.com', 'wikipedia.org',
  'facebook.com', 'instagram.com', 'twitter.com', 'linkedin.com',
  'amazon.com', 'ebay.com', 'mercadolivre.com', 'olx.com.br'
];

export const ESSENTIAL_DOMAINS = [
  'google.com', 'gmail.com', 'accounts.google.com',
  'youtube.com', 'microsoft.com', 'live.com', 'outlook.com',
  'github.com', 'stackoverflow.com', 'wikipedia.org'
];

export const EXCLUDE_FROM_AUTO_WHITELIST = [
  ...ESSENTIAL_DOMAINS,
  'google.com.br', 'mail.google.com', 'drive.google.com',
  'photos.google.com', 'calendar.google.com', 'maps.google.com'
];