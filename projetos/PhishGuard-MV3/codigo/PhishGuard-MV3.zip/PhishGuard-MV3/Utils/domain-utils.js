import {
  SUSPICIOUS_TLDS,
  SUSPICIOUS_PATTERNS,
  DANGEROUS_EXTENSIONS,
  TRUSTED_DOMAINS
} from './constants.js';

export function getDomainFromUrl(url) {
  try { return new URL(url).hostname; } catch { return null; }
}

export function normalizeDomain(domain) {
  if (!domain) return domain;
  return domain.replace(/^www\./, '').toLowerCase().trim();
}

function levenshteinDistance(a, b) {
  const matrix = Array.from({ length: a.length + 1 }, (_, i) => i);
  for (let i = 1; i <= b.length; i++) {
    let prev = i;
    for (let j = 1; j <= a.length; j++) {
      const curr = matrix[j - 1] + (a[j - 1] === b[i - 1] ? 0 : 1);
      matrix[j - 1] = prev;
      prev = Math.min(curr, matrix[j] + 1, prev + 1);
    }
    matrix[a.length] = prev;
  }
  return matrix[a.length];
}

function isTyposquatting(domain, trustedList) {
  const base = normalizeDomain(domain).split('.');
  if (base.length < 2) return false;
  const mainPart = base[base.length - 2];
  const tld = '.' + base[base.length - 1];
  if (SUSPICIOUS_TLDS.includes(tld)) return true;
  for (const trusted of trustedList) {
    const trustedMain = trusted.split('.')[0];
    if (levenshteinDistance(mainPart, trustedMain) <= 2 && mainPart !== trustedMain) {
      return true;
    }
  }
  return false;
}

function isIPAddress(domain) {
  return /^(\d{1,3}\.){3}\d{1,3}$/.test(domain);
}

function hasUnicodeHomoglyphs(domain) {
  return /[Ａ-Ｚａ-ｚ０-９]/.test(domain);
}

function isShortenedUrl(url) {
  const shorteners = ['bit.ly', 'tinyurl', 'goo.gl', 'ow.ly', 'is.gd', 'buff.ly', 't.co'];
  return shorteners.some(s => url.includes(s));
}

export function calculateScore(domain, url, isBlacklisted = false) {
  let score = 100;
  if (isBlacklisted) return 0;
  const normalized = normalizeDomain(domain);
  if (TRUSTED_DOMAINS.includes(normalized)) return 100;

  if (isTyposquatting(domain, TRUSTED_DOMAINS)) score -= 35;
  if (isIPAddress(domain)) score -= 30;
  const tld = '.' + domain.split('.').pop();
  if (SUSPICIOUS_TLDS.includes(tld)) score -= 25;
  for (const pattern of SUSPICIOUS_PATTERNS) {
    if (domain.includes(pattern)) { score -= 20; break; }
  }
  const parts = domain.split('.');
  if (parts.length > 4) score -= 15;
  if (domain.length > 40) score -= 15;
  if (hasUnicodeHomoglyphs(domain)) score -= 30;
  if (isShortenedUrl(url)) score -= 20;
  const mainPart = parts.slice(-2)[0] || '';
  if (/\d/.test(mainPart)) score -= 10;
  for (const ext of DANGEROUS_EXTENSIONS) {
    if (url.toLowerCase().includes(ext)) { score -= 30; break; }
  }
  return Math.max(0, Math.min(100, score));
}

export function getTestResults(domain, url) {
  const tests = [];
  const normalized = normalizeDomain(domain);
  const parts = domain.split('.');
  const tld = '.' + parts.pop();
  const mainPart = parts[parts.length - 1] || '';

  tests.push({
    name: 'Domínio na lista de confiáveis',
    passed: TRUSTED_DOMAINS.includes(normalized),
    description: TRUSTED_DOMAINS.includes(normalized) ? 'Domínio reconhecido como seguro' : 'Domínio não está na lista de confiáveis'
  });

  const typosquatting = isTyposquatting(domain, TRUSTED_DOMAINS);
  tests.push({
    name: 'Typosquatting',
    passed: !typosquatting,
    description: typosquatting ? 'Domínio muito parecido com um site conhecido' : 'Nenhuma similaridade suspeita'
  });

  const ip = isIPAddress(domain);
  tests.push({
    name: 'Domínio é um endereço IP',
    passed: !ip,
    description: ip ? 'O domínio é um IP (ex: 192.168.1.1)' : 'Domínio textual'
  });

  const suspiciousTld = SUSPICIOUS_TLDS.includes(tld);
  tests.push({
    name: 'TLD suspeito',
    passed: !suspiciousTld,
    description: suspiciousTld ? `TLD ${tld} considerado suspeito` : `TLD ${tld} comum`
  });

  let hasSuspiciousPattern = false;
  for (const pattern of SUSPICIOUS_PATTERNS) {
    if (domain.includes(pattern)) { hasSuspiciousPattern = true; break; }
  }
  tests.push({
    name: 'Palavras suspeitas no domínio',
    passed: !hasSuspiciousPattern,
    description: hasSuspiciousPattern ? 'Domínio contém palavras como "crack", "hack", etc.' : 'Nenhuma palavra suspeita'
  });

  const manySubdomains = parts.length > 4;
  tests.push({
    name: 'Número de subdomínios',
    passed: !manySubdomains,
    description: manySubdomains ? `Mais de 4 níveis (${parts.length})` : `${parts.length} níveis (aceitável)`
  });

  const longDomain = domain.length > 40;
  tests.push({
    name: 'Comprimento do domínio',
    passed: !longDomain,
    description: longDomain ? `Domínio com ${domain.length} caracteres (muito longo)` : `${domain.length} caracteres (normal)`
  });

  const homoglyphs = hasUnicodeHomoglyphs(domain);
  tests.push({
    name: 'Caracteres Unicode homógrafos',
    passed: !homoglyphs,
    description: homoglyphs ? 'Domínio contém caracteres que imitam letras comuns (ex: ｇｏｏｇｌｅ)' : 'Apenas caracteres ASCII padrão'
  });

  const shortened = isShortenedUrl(url);
  tests.push({
    name: 'URL encurtada',
    passed: !shortened,
    description: shortened ? 'URL usa serviço de encurtamento (bit.ly, tinyurl, etc.)' : 'URL não encurtada'
  });

  const hasNumbers = /\d/.test(mainPart);
  tests.push({
    name: 'Números no domínio principal',
    passed: !hasNumbers,
    description: hasNumbers ? `Domínio principal contém números (${mainPart})` : 'Sem números no domínio principal'
  });

  let hasDangerousExt = false;
  for (const ext of DANGEROUS_EXTENSIONS) {
    if (url.toLowerCase().includes(ext)) { hasDangerousExt = true; break; }
  }
  tests.push({
    name: 'Extensão de arquivo perigosa',
    passed: !hasDangerousExt,
    description: hasDangerousExt ? 'URL contém extensão executável (.exe, .msi, etc.)' : 'Extensão segura ou sem extensão'
  });

  return tests;
}