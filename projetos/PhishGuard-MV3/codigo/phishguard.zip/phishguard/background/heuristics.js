// heuristics.js
export function calculateRisk(pageData) {
  let score = 0;

  if (pageData.hasPasswordInput) score += 40;
  if (pageData.isNewDomain) score += 45;
  if (pageData.hasHiddenElements) score += 20;
  if (pageData.hasAdultKeywords) score += 70;
  if (pageData.hasInvalidCert) score += 30;
  if (pageData.hasRedirectChain) score += 25;
  if (pageData.hasExternalLoginForm) score += 40;

  return Math.min(score, 100);
}
