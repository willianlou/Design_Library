import { WHITELIST } from '../utils/constants.js';
import { calculateRisk } from './heuristics.js';

function normalizeHost(host) {
  return host.replace(/^www\./i, '').toLowerCase();
}

const processedTabs = new Set();

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete' || !tab.url) return;
  if (processedTabs.has(tabId)) return;

  const domain = new URL(tab.url).hostname;
  const normDomain = normalizeHost(domain);

  const storage = await chrome.storage.local.get(['userWhitelist', 'sessionWhitelist']);
  const userWhitelist = storage.userWhitelist || {};
  const sessionWhitelist = storage.sessionWhitelist || {};

  if (WHITELIST.map(normalizeHost).includes(normDomain) ||
      userWhitelist[normDomain] ||
      sessionWhitelist[normDomain]) {
    return;
  }

  chrome.tabs.sendMessage(tabId, { action: "GET_PAGE_DATA" }, async (response) => {
    if (chrome.runtime.lastError) {
      console.warn('Erro ao coletar dados:', chrome.runtime.lastError.message);
      return;
    }

    const pageData = response || {};
    const score = calculateRisk(pageData);

    await chrome.storage.local.set({ pendingAnalysis: { domain: normDomain, score } });
    processedTabs.add(tabId);

    const analyzingUrl = chrome.runtime.getURL(`pages/analyzing.html?target=${encodeURIComponent(normDomain)}`);
    chrome.tabs.update(tabId, { url: analyzingUrl });
  });
});
