// content/intent-engine.js
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action !== 'GET_PAGE_DATA') return;

  (async () => {
    const hasPasswordInput = !!document.querySelector('input[type="password"]');
    const hasHiddenElements = !!document.querySelector('[style*="display:none"], [hidden]');
    const text = (document.body && document.body.innerText) ? document.body.innerText.toLowerCase() : '';
    const adultKeywords = ['xvideos', 'porn', 'xxx', 'adult', 'sex', 'pornhub', 'login bancário'];
    const hasAdultKeywords = adultKeywords.some(k => text.includes(k));

    // Certificado inválido
    const hasInvalidCert = window.location.protocol !== 'https:';

    // Redirecionamentos em cadeia (simples: se histórico > 1)
    const hasRedirectChain = performance.getEntriesByType('navigation')[0]?.redirectCount > 1;

    // Formulário de login externo (exemplo: login Google fora de google.com)
    let hasExternalLoginForm = false;
    const forms = document.querySelectorAll('form');
    forms.forEach(f => {
      if (f.innerHTML.toLowerCase().includes('google') && !location.hostname.includes('google.com')) {
        hasExternalLoginForm = true;
      }
    });

    const pageData = {
      hasPasswordInput,
      hasHiddenElements,
      isNewDomain: false, // pode ser calculado no background via WHOIS
      hasAdultKeywords,
      hasInvalidCert,
      hasRedirectChain,
      hasExternalLoginForm
    };

    sendResponse(pageData);
  })();

  return true;
});
