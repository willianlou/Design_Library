const tips = [
  "Nunca compartilhe suas senhas.",
  "Não clique em links suspeitos.",
  "Verifique o endereço do site antes de digitar dados.",
  "Use autenticação em dois fatores.",
  "Mantenha seu navegador atualizado.",
  "Desconfie de ofertas boas demais.",
  "Não baixe arquivos de fontes desconhecidas.",
  "Evite usar Wi-Fi público sem VPN.",
  "Cheque se o site tem HTTPS.",
  "Nunca forneça dados bancários por e-mail."
];

const stories = [
  "Um clique errado transformou o navegador em um simulador de vacas mugindo.",
  "Um login suspeito virou sua conta em um fã-clube de pinguins dançantes.",
  "Um site falso entregou apenas um PDF com receitas de sopa de pedra.",
  "Um download duvidoso instalou o jogo Corrida de Lesmas 3000.",
  "Um certificado inválido levou a um site que vendia botões quebrados.",
  "Um redirecionamento terminou em um blog sobre treinar formigas.",
  "Um formulário falso inscreveu a vítima em campeonato de dobrar guardanapos.",
  "Um clique em phishing gerou boleto para a Lua.",
  "Um login roubado virou curso de assobiar para plantas.",
  "Um site suspeito fez a conta virar loja de geladeiras invisíveis."
];

const bar = document.getElementById('bar');
const tipEl = document.getElementById('tip');
let width = 0;
let step = 0;

const interval = setInterval(() => {
  width += 20;
  bar.style.width = width + '%';
  tipEl.textContent = (step % 2 === 0)
    ? tips[Math.floor(Math.random() * tips.length)]
    : stories[Math.floor(Math.random() * stories.length)];
  step++;
  if (width >= 100) clearInterval(interval);
}, 1000);

setTimeout(async () => {
  const data = await chrome.storage.local.get('pendingAnalysis');
  if (data.pendingAnalysis) {
    const { domain, score } = data.pendingAnalysis;
    const mode = score >= 80 ? 'hard' : 'soft';
    const blockedUrl = chrome.runtime.getURL(
      `pages/blocked.html?target=${encodeURIComponent(domain)}&score=${score}&mode=${mode}`
    );
    window.location.href = blockedUrl;
  }
}, 5000);
