const params = new URLSearchParams(window.location.search);
const domain = params.get('target');

document.addEventListener('DOMContentLoaded', () => {
  const permBtn = document.getElementById('trust-permanent-btn');

  if (permBtn) {
    permBtn.addEventListener('click', async () => {
      const storage = await chrome.storage.local.get('userWhitelist');
      const userWhitelist = storage.userWhitelist || {};
      userWhitelist[domain] = true;
      await chrome.storage.local.set({ userWhitelist });
      window.location.href = "https://" + domain;
    });
  }
});
